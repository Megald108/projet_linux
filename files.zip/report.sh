#!/usr/bin/env bash
# =============================================================================
# ATDP - report.sh
# Phase 12 : rapport final
# =============================================================================

ATDP_START_TIME="${ATDP_START_TIME:-$(date +%s)}"

generate_report() {
    local success="${1:-1}"   # 0 = succès, 1 = échec
    local dir="${2:-$ATDP_PROJECT_DIR}"

    log_step "PHASE 12 : Rapport final"

    # Infos sur le projet
    local sw_name
    sw_name="$(basename "${dir}" | sed 's/[-_][0-9].*//')"

    local sw_version=""
    # Cherche la version dans le nom du dossier
    sw_version="$(basename "${dir}" | grep -oP '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -1)"
    # Ou depuis configure.ac / CMakeLists
    if [[ -z "$sw_version" ]] && [[ -f "${dir}/configure.ac" ]]; then
        sw_version="$(grep -m1 'AC_INIT' "${dir}/configure.ac" 2>/dev/null | grep -oP '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -1)"
    fi
    if [[ -z "$sw_version" ]] && [[ -f "${dir}/CMakeLists.txt" ]]; then
        sw_version="$(grep -m1 'VERSION' "${dir}/CMakeLists.txt" 2>/dev/null | grep -oP '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -1)"
    fi
    [[ -z "$sw_version" ]] && sw_version="inconnue"

    # Durée
    local elapsed
    elapsed="$(log_elapsed "$ATDP_START_TIME")"

    # Dépendances installées
    local deps_str="aucune"
    if [[ ${#ATDP_INSTALLED_DEPS[@]} -gt 0 ]]; then
        deps_str="${ATDP_INSTALLED_DEPS[*]}"
    fi

    # Résultat
    local result_str
    local result_color
    if [[ "$success" -eq 0 ]]; then
        result_str="✔  SUCCÈS"
        result_color="\e[32;1m"
    else
        result_str="✘  ÉCHEC"
        result_color="\e[31;1m"
    fi

    echo ""
    echo -e "\e[1m+========================================================+\e[0m"
    echo -e "\e[1m|             RAPPORT D'INSTALLATION                     |\e[0m"
    echo -e "\e[1m+========================================================+\e[0m"
    printf "\e[1m|\e[0m  %-20s %-31s\e[1m|\e[0m\n" "Logiciel"      "$sw_name"
    printf "\e[1m|\e[0m  %-20s %-31s\e[1m|\e[0m\n" "Version"       "$sw_version"
    printf "\e[1m|\e[0m  %-20s %-31s\e[1m|\e[0m\n" "Methode"       "$ATDP_BUILD_SYSTEM"
    printf "\e[1m|\e[0m  %-20s %-31s\e[1m|\e[0m\n" "Duree totale"  "$elapsed"
    printf "\e[1m|\e[0m  %-20s %-31s\e[1m|\e[0m\n" "Dependances"   "$deps_str"
    printf "\e[1m|\e[0m  %-20s %-31s\e[1m|\e[0m\n" "Journal"       "$ATDP_LOG_FILE"
    printf "\e[1m|\e[0m  %-20s %-31s\e[1m|\e[0m\n" "Mode"          "$ATDP_INPUT_MODE"
    echo -e "\e[1m+========================================================+\e[0m"
    printf "|  Resultat :  ${result_color}%-42s\e[0m\e[1m|\e[0m\n" "$result_str"
    echo -e "\e[1m+========================================================+\e[0m"
    echo ""

    # Écrire le rapport dans le log
    {
        echo "=== RAPPORT FINAL ==="
        echo "Logiciel    : $sw_name"
        echo "Version     : $sw_version"
        echo "Méthode     : $ATDP_BUILD_SYSTEM"
        echo "Durée       : $elapsed"
        echo "Dépendances : $deps_str"
        echo "Résultat    : $result_str"
        echo "===================="
    } >> "$ATDP_LOG_FILE"
}
