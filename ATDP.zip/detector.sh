#!/usr/bin/env bash
# =============================================================================
# ATDP - detector.sh  (Phase 0 : vérification de l'environnement)
# =============================================================================

ATDP_MIN_DISK_MB="${ATDP_MIN_DISK_MB:-500}"

# Liste des outils indispensables au fonctionnement d'ATDP
_ESSENTIAL_TOOLS=(
    wget curl tar gzip xz bzip2 unzip file
    make gcc g++ pkg-config
    autoconf automake libtool
    patch sed awk grep find
)

# Outils optionnels mais utiles
_OPTIONAL_TOOLS=(
    cmake meson ninja-build
    python3 ruby nodejs cargo go
    git p7zip-full lzip
    sha256sum md5sum gpg
    nproc
)

# =============================================================================
# Phase 0 : Vérification complète de l'environnement
# =============================================================================
check_environment() {
    log_step "PHASE 0 : Vérification de l'environnement"
    local errors=0

    # -- Système Linux ---------------------------------------------------------
    if [[ "$(uname -s)" != "Linux" ]]; then
        log_error "ATDP fonctionne uniquement sous Linux (détecté : $(uname -s))"
        (( errors++ ))
    else
        log_ok "Système : Linux $(uname -r)"
    fi

    # -- Distribution ----------------------------------------------------------
    local distro pm
    distro="$(detect_distro)"
    pm="$(detect_pkg_manager)"
    log_info "Distribution : $distro  |  Gestionnaire de paquets : $pm"
    if [[ "$pm" == "unknown" ]]; then
        log_warn "Gestionnaire de paquets non reconnu — l'installation automatique des dépendances pourrait échouer."
    fi

    # -- Architecture ----------------------------------------------------------
    local arch
    arch="$(uname -m)"
    log_info "Architecture : $arch"

    # -- sudo ------------------------------------------------------------------
    if is_root; then
        log_ok "Exécution en root — sudo non nécessaire"
    elif sudo -n true 2>/dev/null; then
        log_ok "sudo disponible et opérationnel"
    else
        log_warn "sudo non disponible sans mot de passe — il vous sera demandé lors des installations."
    fi

    # -- Connexion Internet ----------------------------------------------------
    if check_internet; then
        log_ok "Connexion Internet : disponible"
    else
        log_warn "Connexion Internet : non disponible — les téléchargements et installations de paquets seront impossibles."
    fi

    # -- Espace disque ---------------------------------------------------------
    local free_mb
    free_mb="$(free_disk_mb /tmp)"
    if [[ -n "$free_mb" && "$free_mb" -lt "$ATDP_MIN_DISK_MB" ]]; then
        log_error "Espace disque insuffisant : ${free_mb} Mo disponibles (minimum : ${ATDP_MIN_DISK_MB} Mo)"
        (( errors++ ))
    else
        log_ok "Espace disque : ${free_mb:-?} Mo disponibles"
    fi

    # -- Outils essentiels -----------------------------------------------------
    log_info "Vérification des outils essentiels..."
    local missing_essential=()
    for tool in "${_ESSENTIAL_TOOLS[@]}"; do
        if ! command_exists "$tool"; then
            missing_essential+=("$tool")
        fi
    done

    if [[ ${#missing_essential[@]} -gt 0 ]]; then
        log_warn "Outils essentiels manquants : ${missing_essential[*]}"
        log_info "Tentative d'installation automatique..."
        update_pkg_index
        for tool in "${missing_essential[@]}"; do
            local pkg
            pkg="$(_tool_to_pkg "$tool" "$pm")"
            if install_package "$pkg" >> "$ATDP_LOG_FILE" 2>&1; then
                log_ok "  ✔ $tool installé"
            else
                log_error "  ✘ Impossible d'installer $tool ($pkg)"
                (( errors++ ))
            fi
        done
    else
        log_ok "Tous les outils essentiels sont présents"
    fi

    # -- Outils optionnels (informatif seulement) ------------------------------
    local missing_opt=()
    for tool in "${_OPTIONAL_TOOLS[@]}"; do
        command_exists "$tool" || missing_opt+=("$tool")
    done
    if [[ ${#missing_opt[@]} -gt 0 ]]; then
        log_debug "Outils optionnels absents : ${missing_opt[*]}"
    fi

    # -- Résultat --------------------------------------------------------------
    if [[ "$errors" -gt 0 ]]; then
        log_error "Environnement incomplet ($errors erreur(s) critique(s)). Abandon."
        return 1
    fi
    log_ok "Environnement validé."
    return 0
}

# Correspondance outil → paquet selon le gestionnaire
_tool_to_pkg() {
    local tool="$1"
    local pm="$2"
    case "$pm" in
        apt)
            case "$tool" in
                wget)        echo "wget" ;;
                curl)        echo "curl" ;;
                tar)         echo "tar" ;;
                gzip)        echo "gzip" ;;
                xz)          echo "xz-utils" ;;
                bzip2)       echo "bzip2" ;;
                unzip)       echo "unzip" ;;
                file)        echo "file" ;;
                make)        echo "make" ;;
                gcc)         echo "gcc" ;;
                g++)         echo "g++" ;;
                pkg-config)  echo "pkg-config" ;;
                autoconf)    echo "autoconf" ;;
                automake)    echo "automake" ;;
                libtool)     echo "libtool" ;;
                patch)       echo "patch" ;;
                nproc)       echo "coreutils" ;;
                *)           echo "$tool" ;;
            esac
            ;;
        dnf|yum)
            case "$tool" in
                g++)         echo "gcc-c++" ;;
                pkg-config)  echo "pkgconf-pkg-config" ;;
                xz)          echo "xz" ;;
                *)           echo "$tool" ;;
            esac
            ;;
        pacman)
            case "$tool" in
                g++)         echo "gcc" ;;
                pkg-config)  echo "pkgconf" ;;
                xz)          echo "xz" ;;
                *)           echo "$tool" ;;
            esac
            ;;
        *)
            echo "$tool"
            ;;
    esac
}
