#!/usr/bin/env bash
# =============================================================================
# ATDP - installer.sh
# Phase 8-10 : vérification post-build, installation, vérification finale
# =============================================================================

ATDP_INSTALLED_BINARIES=()

# =============================================================================
# Phase 8 : Vérification post-compilation
# =============================================================================
verify_build() {
    local dir="$1"
    log_step "PHASE 8 : Vérification post-compilation"

    # Cherche les binaires produits (ELF exécutables)
    local bins=()
    mapfile -t bins < <(find "$dir" -maxdepth 6 -type f \
        ! -path '*/.git/*' \
        ! -path '*/CMakeFiles/*' \
        ! -name '*.o' ! -name '*.a' ! -name '*.so*' \
        -executable 2>/dev/null | head -20)

    if [[ ${#bins[@]} -eq 0 ]]; then
        # Cargo : target/release/
        mapfile -t bins < <(find "${dir}/target/release" -maxdepth 1 -type f -executable 2>/dev/null)
    fi

    if [[ ${#bins[@]} -eq 0 ]]; then
        log_warn "Aucun exécutable trouvé après compilation — peut être normal (lib, Python, Node)."
    else
        log_info "Exécutables produits :"
        for b in "${bins[@]}"; do
            file "$b" 2>/dev/null | grep -q ELF && log_info "  • $(basename "$b")"
        done
    fi

    log_ok "Vérification post-compilation terminée."
    return 0
}

# =============================================================================
# Phase 9 : Installation
# =============================================================================
install_project() {
    local dir="$1"
    log_step "PHASE 9 : Installation"

    case "$ATDP_BUILD_SYSTEM" in
        meson)
            log_info "  → ninja install (meson)"
            run_privileged ninja -C "${ATDP_BUILD_DIR:-${dir}/build_atdp}" install 2>&1 | tee -a "$ATDP_LOG_FILE"
            ;;
        cmake)
            log_info "  → cmake --install"
            run_privileged cmake --install "${ATDP_BUILD_DIR:-${dir}/build_atdp}" 2>&1 | tee -a "$ATDP_LOG_FILE"
            ;;
        cargo)
            log_info "  → cargo install"
            # shellcheck disable=SC1090
            source "$HOME/.cargo/env" 2>/dev/null || true
            (cd "$dir" && cargo install --path . 2>&1 | tee -a "$ATDP_LOG_FILE")
            ;;
        golang)
            log_info "  → go install"
            (cd "$dir" && go install ./... 2>&1 | tee -a "$ATDP_LOG_FILE")
            ;;
        python)
            log_info "  → pip3 install / python3 setup.py install"
            if [[ -f "${dir}/pyproject.toml" ]]; then
                (cd "$dir" && run_privileged pip3 install . 2>&1 | tee -a "$ATDP_LOG_FILE")
            else
                (cd "$dir" && run_privileged python3 setup.py install 2>&1 | tee -a "$ATDP_LOG_FILE")
            fi
            ;;
        nodejs)
            log_info "  → npm install -g"
            (cd "$dir" && run_privileged npm install -g . 2>&1 | tee -a "$ATDP_LOG_FILE")
            ;;
        scons)
            log_info "  → scons install"
            (cd "$dir" && run_privileged scons install 2>&1 | tee -a "$ATDP_LOG_FILE")
            ;;
        ninja)
            log_info "  → ninja install"
            (cd "$dir" && run_privileged ninja install 2>&1 | tee -a "$ATDP_LOG_FILE")
            ;;
        *)
            # Autotools / make classique
            log_info "  → make install"
            (cd "$dir" && run_privileged make install 2>&1 | tee -a "$ATDP_LOG_FILE")
            ;;
    esac

    local ret="${PIPESTATUS[0]}"
    if [[ "$ret" -ne 0 ]]; then
        log_error "Installation échouée (code $ret)."
        return "$ret"
    fi

    log_ok "Installation terminée."
    return 0
}

# =============================================================================
# Phase 10 : Vérification finale
# =============================================================================
verify_installation() {
    local dir="$1"
    local software_name
    software_name="$(basename "$dir" | sed 's/[-_][0-9].*//')"
    log_step "PHASE 10 : Vérification finale"

    # Cherche le binaire principal dans le PATH
    local bin_found=""
    local candidate_bins=(
        "$software_name"
        "${software_name,,}"
        "$(echo "$software_name" | tr '[:upper:]' '[:lower:]')"
    )

    for b in "${candidate_bins[@]}"; do
        if command_exists "$b"; then
            bin_found="$b"
            break
        fi
    done

    if [[ -n "$bin_found" ]]; then
        log_ok "Binaire '$bin_found' trouvé dans le PATH."
        ATDP_INSTALLED_BINARIES+=("$bin_found")

        # Test --version
        local version_output
        version_output="$("$bin_found" --version 2>&1 | head -1)" || \
        version_output="$("$bin_found" -version 2>&1 | head -1)" || \
        version_output="(test --version non disponible)"
        log_info "Version : $version_output"
        export ATDP_INSTALLED_VERSION="$version_output"
    else
        log_warn "Binaire '$software_name' non trouvé dans le PATH."
        log_warn "L'installation a peut-être réussi dans un chemin non standard."

        # Cherche dans /usr/local/bin, /usr/bin, etc.
        local found_path
        found_path="$(find /usr/local/bin /usr/bin /opt /usr/local/sbin 2>/dev/null \
            -name "${software_name}*" -type f -executable 2>/dev/null | head -3)"
        if [[ -n "$found_path" ]]; then
            log_info "Fichiers trouvés :"
            echo "$found_path" | while IFS= read -r p; do log_info "  • $p"; done
        fi
    fi

    return 0
}
