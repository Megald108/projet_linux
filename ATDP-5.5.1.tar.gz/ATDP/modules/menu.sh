#!/usr/bin/env bash
# =============================================================================
# ATDP - menu.sh
# Interface utilisateur : menu principal et saisies
# =============================================================================

# Résultat des fonctions de saisie (variables globales)
ATDP_ARCHIVE_PATH=""
ATDP_ARCHIVE_URL=""
ATDP_INPUT_MODE=""   # "local" ou "url"

# =============================================================================
# Affiche le bandeau de bienvenue
# =============================================================================
show_banner() {
    echo ""
    echo -e "\e[34;1m"
    cat << 'EOF'
   ___  _____ ____  ____
  / _ \|_   _|  _ \|  _ \
 | | | | | | | | | | |_) |
 | |_| | | | | |_| |  __/
  \___/  |_| |____/|_|
 Automatic Tarball Deployment Platform
EOF
    echo -e "\e[0m"
    echo -e "\e[90m  Version 5.5  —  Compilation automatisée depuis sources\e[0m"
    echo ""
}

# =============================================================================
# Menu principal : choix du mode
# =============================================================================
menu_main() {
    while true; do
        echo -e "\e[1m  +-----------------------------------+\e[0m"
        echo -e "\e[1m  |       Choisissez un mode          |\e[0m"
        echo -e "\e[1m  +-----------------------------------+\e[0m"
        echo -e "\e[1m  |  1 | Archive locale               |\e[0m"
        echo -e "\e[1m  |  2 | Telecharger depuis Internet  |\e[0m"
        echo -e "\e[1m  |  3 | Quitter                      |\e[0m"
        echo -e "\e[1m  +-----------------------------------+\e[0m"
        echo ""
        read -r -p "  Votre choix [1/2/3] : " choice
        echo ""

        case "$choice" in
            1)
                if _menu_input_local; then
                    ATDP_INPUT_MODE="local"
                    return 0
                fi
                ;;
            2)
                if _menu_input_url; then
                    ATDP_INPUT_MODE="url"
                    return 0
                fi
                ;;
            3|q|Q)
                echo "  Au revoir."
                exit 0
                ;;
            *)
                echo -e "\e[33m  Choix invalide. Veuillez entrer 1, 2 ou 3.\e[0m"
                echo ""
                ;;
        esac
    done
}

# =============================================================================
# Saisie : archive locale
# =============================================================================
_menu_input_local() {
    while true; do
        echo -e "  \e[1mChemin de l'archive :\e[0m"
        read -r -p "  > " path_input
        echo ""

        # Expansion ~
        path_input="${path_input/#\~/$HOME}"

        if [[ -z "$path_input" ]]; then
            echo -e "\e[33m  Chemin vide. Réessayez.\e[0m\n"
            continue
        fi

        if [[ ! -f "$path_input" ]]; then
            echo -e "\e[31m  Fichier introuvable : $path_input\e[0m\n"
            read -r -p "  Réessayer ? [O/n] " retry
            [[ "${retry,,}" == "n" ]] && return 1
            continue
        fi

        ATDP_ARCHIVE_PATH="$path_input"
        return 0
    done
}

# =============================================================================
# Saisie : URL de téléchargement
# =============================================================================
_menu_input_url() {
    while true; do
        echo -e "  \e[1mURL de l'archive :\e[0m"
        read -r -p "  > " url_input
        echo ""

        if [[ -z "$url_input" ]]; then
            echo -e "\e[33m  URL vide. Réessayez.\e[0m\n"
            continue
        fi

        if [[ ! "$url_input" =~ ^https?:// && ! "$url_input" =~ ^ftp:// ]]; then
            echo -e "\e[33m  URL invalide (doit commencer par http:// https:// ou ftp://)\e[0m\n"
            continue
        fi

        ATDP_ARCHIVE_URL="$url_input"
        return 0
    done
}

# =============================================================================
# Résumé avant démarrage
# =============================================================================
menu_confirm_start() {
    echo ""
    echo -e "\e[1m  ── Résumé ─────────────────────────────────────────\e[0m"
    if [[ "$ATDP_INPUT_MODE" == "local" ]]; then
        echo -e "  Mode     : \e[32mArchive locale\e[0m"
        echo -e "  Fichier  : $ATDP_ARCHIVE_PATH"
    else
        echo -e "  Mode     : \e[32mTéléchargement\e[0m"
        echo -e "  URL      : $ATDP_ARCHIVE_URL"
    fi
    echo -e "  Journal  : $ATDP_LOG_FILE"
    echo -e "\e[1m  ───────────────────────────────────────────────────\e[0m"
    echo ""
    if [[ "${ATDP_YES:-0}" == "1" ]]; then
        return 0
    fi
    confirm "  Démarrer l'installation ?"
}
