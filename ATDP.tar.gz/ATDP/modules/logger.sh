#!/usr/bin/env bash
# =============================================================================
# ATDP - logger.sh
# Journalisation horodatée avec niveaux INFO / WARN / ERROR / DEBUG
# =============================================================================

ATDP_LOG_FILE="${ATDP_LOG_FILE:-/tmp/atdp_session.log}"
ATDP_LOG_LEVEL="${ATDP_LOG_LEVEL:-INFO}"   # DEBUG < INFO < WARN < ERROR
ATDP_DEBUG="${ATDP_DEBUG:-0}"

# Couleurs ANSI
_CLR_RESET="\e[0m"
_CLR_INFO="\e[32m"      # vert
_CLR_WARN="\e[33m"      # jaune
_CLR_ERROR="\e[31m"     # rouge
_CLR_DEBUG="\e[36m"     # cyan
_CLR_STEP="\e[34;1m"    # bleu gras
_CLR_OK="\e[32;1m"      # vert gras
_CLR_TITLE="\e[35;1m"   # magenta gras

# -----------------------------------------------------------------------------
log_init() {
    local log_dir
    log_dir="$(dirname "$ATDP_LOG_FILE")"
    mkdir -p "$log_dir"
    {
        echo "================================================="
        echo " ATDP - Session démarrée : $(date '+%Y-%m-%d %H:%M:%S')"
        echo "================================================="
    } >> "$ATDP_LOG_FILE"
}

# Niveau numérique
_log_level_num() {
    case "$1" in
        DEBUG) echo 0 ;;
        INFO)  echo 1 ;;
        WARN)  echo 2 ;;
        ERROR) echo 3 ;;
        *)     echo 1 ;;
    esac
}

_log_write() {
    local level="$1"; shift
    local msg="$*"
    local ts
    ts="$(date '+%Y-%m-%d %H:%M:%S')"

    local current_num
    current_num="$(_log_level_num "$ATDP_LOG_LEVEL")"
    local msg_num
    msg_num="$(_log_level_num "$level")"

    # Toujours écrire dans le fichier
    echo "[$ts] [$level] $msg" >> "$ATDP_LOG_FILE"

    # Afficher à l'écran si niveau suffisant
    [[ "$msg_num" -ge "$current_num" ]] || return 0

    local color
    case "$level" in
        INFO)  color="$_CLR_INFO"  ;;
        WARN)  color="$_CLR_WARN"  ;;
        ERROR) color="$_CLR_ERROR" ;;
        DEBUG) color="$_CLR_DEBUG" ;;
        *)     color=""            ;;
    esac
    echo -e "${color}[${level}]${_CLR_RESET} $msg"
}

log_info()  { _log_write INFO  "$@"; }
log_warn()  { _log_write WARN  "$@"; }
log_error() { _log_write ERROR "$@"; }
log_debug() { [[ "$ATDP_DEBUG" == "1" ]] && _log_write DEBUG "$@" || true; }

# Affichage d'une étape importante (pas de préfixe niveau)
log_step() {
    local msg="$*"
    local ts
    ts="$(date '+%Y-%m-%d %H:%M:%S')"
    echo "[$ts] [STEP] $msg" >> "$ATDP_LOG_FILE"
    echo -e "\n${_CLR_STEP}==> $msg${_CLR_RESET}"
}

log_ok() {
    local msg="$*"
    local ts
    ts="$(date '+%Y-%m-%d %H:%M:%S')"
    echo "[$ts] [OK] $msg" >> "$ATDP_LOG_FILE"
    echo -e "${_CLR_OK}  ✔ $msg${_CLR_RESET}"
}

log_title() {
    local msg="$*"
    echo ""
    echo -e "${_CLR_TITLE}+============================================+${_CLR_RESET}"
    echo -e "${_CLR_TITLE}|  $msg${_CLR_RESET}"
    echo -e "${_CLR_TITLE}+============================================+${_CLR_RESET}"
    echo ""
    echo "[$( date '+%Y-%m-%d %H:%M:%S')] [TITLE] $msg" >> "$ATDP_LOG_FILE"
}

# Durée depuis un timestamp (secondes)
log_elapsed() {
    local start="$1"
    local end
    end="$(date +%s)"
    local diff=$(( end - start ))
    local h=$(( diff / 3600 ))
    local m=$(( (diff % 3600) / 60 ))
    local s=$(( diff % 60 ))
    printf "%02dh %02dm %02ds" "$h" "$m" "$s"
}
