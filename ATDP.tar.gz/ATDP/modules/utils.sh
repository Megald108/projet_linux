#!/usr/bin/env bash
# =============================================================================
# ATDP - utils.sh
# Fonctions utilitaires génériques
# =============================================================================

# Vérifie si une commande existe
command_exists() {
    command -v "$1" &>/dev/null
}

# Vérifie si on est root
is_root() {
    [[ "$EUID" -eq 0 ]]
}

# Exécution sudo si nécessaire
run_privileged() {
    if is_root; then
        "$@"
    else
        sudo "$@"
    fi
}

# Affiche une barre de progression simple
progress_bar() {
    local current="$1"
    local total="$2"
    local width=40
    local pct=$(( current * 100 / total ))
    local filled=$(( current * width / total ))
    local empty=$(( width - filled ))
    printf "\r  ["
    printf "%${filled}s" | tr ' ' '█'
    printf "%${empty}s" | tr ' ' '░'
    printf "] %3d%%" "$pct"
    [[ "$current" -eq "$total" ]] && echo ""
}

# Spinner pendant une commande longue
spinner_run() {
    local msg="$1"; shift
    local spin=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
    local i=0
    "$@" &
    local pid=$!
    while kill -0 "$pid" 2>/dev/null; do
        printf "\r  %s %s  " "${spin[$i]}" "$msg"
        i=$(( (i + 1) % ${#spin[@]} ))
        sleep 0.1
    done
    wait "$pid"
    local ret=$?
    printf "\r  %-60s\r" ""
    return "$ret"
}

# Retourne la taille humainement lisible d'un fichier
human_size() {
    local file="$1"
    if command_exists numfmt; then
        numfmt --to=iec "$(stat -c%s "$file" 2>/dev/null || echo 0)"
    else
        du -sh "$file" 2>/dev/null | cut -f1
    fi
}

# Nombre de cœurs CPU
cpu_cores() {
    nproc 2>/dev/null || grep -c ^processor /proc/cpuinfo 2>/dev/null || echo 1
}

# Espace disque disponible en Mo sur un répertoire
free_disk_mb() {
    local dir="${1:-/}"
    df -m "$dir" 2>/dev/null | awk 'NR==2{print $4}'
}

# Demande une confirmation y/n
confirm() {
    local prompt="${1:-Continuer ?} [O/n] "
    local answer
    read -r -p "$prompt" answer
    case "${answer,,}" in
        ""|o|oui|y|yes) return 0 ;;
        *) return 1 ;;
    esac
}

# Trim d'une chaîne
trim() {
    local s="$1"
    s="${s#"${s%%[![:space:]]*}"}"
    s="${s%"${s##*[![:space:]]}"}"
    echo "$s"
}

# Vérifie la connexion Internet
check_internet() {
    if ping -c1 -W3 8.8.8.8 &>/dev/null || \
       curl -s --max-time 5 https://www.google.com &>/dev/null; then
        return 0
    fi
    return 1
}

# Résolution du nom de distro
detect_distro() {
    if [[ -f /etc/os-release ]]; then
        # shellcheck disable=SC1091
        source /etc/os-release
        echo "${ID:-unknown}"
    elif command_exists lsb_release; then
        lsb_release -si | tr '[:upper:]' '[:lower:]'
    else
        echo "unknown"
    fi
}

# Gestionnaire de paquets selon la distro
detect_pkg_manager() {
    local distro
    distro="$(detect_distro)"
    case "$distro" in
        ubuntu|debian|linuxmint|pop|kali|raspbian)
            echo "apt" ;;
        fedora|rhel|centos|rocky|alma)
            command_exists dnf && echo "dnf" || echo "yum" ;;
        arch|manjaro|endeavouros)
            echo "pacman" ;;
        opensuse*|suse*)
            echo "zypper" ;;
        *)
            command_exists apt   && echo "apt"    && return
            command_exists dnf   && echo "dnf"    && return
            command_exists yum   && echo "yum"    && return
            command_exists pacman && echo "pacman" && return
            echo "unknown"
            ;;
    esac
}

# Installation d'un paquet (abstraction multi-distro)
install_package() {
    local pkg="$1"
    local pm
    pm="$(detect_pkg_manager)"
    log_info "Installation du paquet : $pkg (via $pm)"
    case "$pm" in
        apt)
            run_privileged apt-get install -y "$pkg" 2>&1
            ;;
        dnf|yum)
            run_privileged "$pm" install -y "$pkg" 2>&1
            ;;
        pacman)
            run_privileged pacman -S --noconfirm "$pkg" 2>&1
            ;;
        zypper)
            run_privileged zypper install -y "$pkg" 2>&1
            ;;
        *)
            log_error "Gestionnaire de paquets inconnu : $pm"
            return 1
            ;;
    esac
}

# Mise à jour de l'index des paquets (une seule fois par session)
_PKG_INDEX_UPDATED=0
update_pkg_index() {
    [[ "$_PKG_INDEX_UPDATED" -eq 1 ]] && return 0
    local pm
    pm="$(detect_pkg_manager)"
    case "$pm" in
        apt)    run_privileged apt-get update -qq 2>&1 ;;
        dnf|yum) run_privileged "$pm" makecache -q 2>&1 ;;
        pacman) run_privileged pacman -Sy --noconfirm 2>&1 ;;
        zypper) run_privileged zypper refresh 2>&1 ;;
    esac
    _PKG_INDEX_UPDATED=1
}
