#!/usr/bin/env bash
# =============================================================================
# ATDP - cleanup.sh
# Phase 11 : nettoyage des fichiers temporaires
# =============================================================================

cleanup_workspace() {
    log_step "PHASE 11 : Nettoyage"

    local keep_archive="${ATDP_KEEP_ARCHIVE:-0}"
    local keep_src="${ATDP_KEEP_SRC:-0}"

    # Supprimer le dossier d'extraction
    if [[ "$keep_src" != "1" ]] && [[ -d "$ATDP_EXTRACT_DIR" ]]; then
        log_info "Suppression du dossier source temporaire..."
        rm -rf "$ATDP_EXTRACT_DIR"
        log_ok "Dossier source supprimé."
    else
        log_info "Sources conservées dans : $ATDP_EXTRACT_DIR"
    fi

    # Supprimer l'archive téléchargée (si elle était dans tmp)
    if [[ "$keep_archive" != "1" ]] \
       && [[ "$ATDP_INPUT_MODE" == "url" ]] \
       && [[ -f "$ATDP_ARCHIVE_PATH" ]] \
       && [[ "$ATDP_ARCHIVE_PATH" == "${ATDP_TMP_DIR}"* ]]; then
        log_info "Suppression de l'archive téléchargée..."
        rm -f "$ATDP_ARCHIVE_PATH"
        log_ok "Archive supprimée."
    fi

    log_ok "Nettoyage terminé."
}

# Nettoyage d'urgence (trap)
emergency_cleanup() {
    echo ""
    log_warn "Interruption détectée — nettoyage d'urgence..."
    [[ -d "$ATDP_EXTRACT_DIR" ]] && rm -rf "$ATDP_EXTRACT_DIR"
    log_info "Nettoyage d'urgence terminé."
}
