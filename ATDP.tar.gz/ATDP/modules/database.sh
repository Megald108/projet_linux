#!/usr/bin/env bash
# =============================================================================
# ATDP - database.sh
# Base de données interne : en-têtes / bibliothèques → paquets Debian/Ubuntu
# Supporte aussi Fedora/Arch/openSUSE via des tables secondaires
# =============================================================================

ATDP_DB_DIR="${ATDP_DB_DIR:-${ATDP_ROOT}/database}"

# =============================================================================
# TABLE PRINCIPALE : correspondances header → paquet Debian/Ubuntu
# Format : "header_ou_lib:paquet_debian[:paquet_fedora[:paquet_arch]]"
# =============================================================================
_DB_ENTRIES=(
    # ── Compression ──────────────────────────────────────────────────────────
    "zlib.h:zlib1g-dev:zlib-devel:zlib"
    "bzlib.h:libbz2-dev:bzip2-devel:bzip2"
    "lzma.h:liblzma-dev:xz-devel:xz"
    "lz4.h:liblz4-dev:lz4-devel:lz4"
    "zstd.h:libzstd-dev:libzstd-devel:zstd"
    "snappy.h:libsnappy-dev:snappy-devel:snappy"

    # ── SSL / TLS ─────────────────────────────────────────────────────────────
    "openssl/ssl.h:libssl-dev:openssl-devel:openssl"
    "openssl/evp.h:libssl-dev:openssl-devel:openssl"
    "openssl/rsa.h:libssl-dev:openssl-devel:openssl"
    "gnutls/gnutls.h:libgnutls28-dev:gnutls-devel:gnutls"
    "nss.h:libnss3-dev:nss-devel:nss"

    # ── Interfaces graphiques ─────────────────────────────────────────────────
    "gtk/gtk.h:libgtk-3-dev:gtk3-devel:gtk3"
    "gtk4/gtk.h:libgtk-4-dev:gtk4-devel:gtk4"
    "gdk/gdk.h:libgtk-3-dev:gtk3-devel:gtk3"
    "glib-2.0/glib.h:libglib2.0-dev:glib2-devel:glib2"
    "gio/gio.h:libglib2.0-dev:glib2-devel:glib2"
    "gobject/gobject.h:libglib2.0-dev:glib2-devel:glib2"
    "pango/pango.h:libpango1.0-dev:pango-devel:pango"
    "cairo/cairo.h:libcairo2-dev:cairo-devel:cairo"
    "atk/atk.h:libatk1.0-dev:atk-devel:at-spi2-atk"
    "gdk-pixbuf/gdk-pixbuf.h:libgdk-pixbuf2.0-dev:gdk-pixbuf2-devel:gdk-pixbuf2"
    "wx/wx.h:libwxgtk3.0-dev:wxGTK3-devel:wxgtk3"
    "QApplication:qtbase5-dev:qt5-qtbase-devel:qt5-base"
    "QMainWindow:qtbase5-dev:qt5-qtbase-devel:qt5-base"
    "QWidget:qtbase5-dev:qt5-qtbase-devel:qt5-base"

    # ── XML / JSON ────────────────────────────────────────────────────────────
    "libxml/parser.h:libxml2-dev:libxml2-devel:libxml2"
    "libxml2/libxml/parser.h:libxml2-dev:libxml2-devel:libxml2"
    "libxslt/xslt.h:libxslt1-dev:libxslt-devel:libxslt"
    "expat.h:libexpat1-dev:expat-devel:expat"
    "json/json.h:libjsoncpp-dev:jsoncpp-devel:jsoncpp"
    "jansson.h:libjansson-dev:jansson-devel:jansson"
    "yajl/yajl_gen.h:libyajl-dev:yajl-devel:yajl"
    "yaml.h:libyaml-dev:libyaml-devel:libyaml"
    "yaml-cpp/yaml.h:libyaml-cpp-dev:yaml-cpp-devel:yaml-cpp"

    # ── Base de données ───────────────────────────────────────────────────────
    "sqlite3.h:libsqlite3-dev:sqlite-devel:sqlite"
    "mysql/mysql.h:libmysqlclient-dev:mysql-devel:mariadb-libs"
    "mysql.h:libmysqlclient-dev:mysql-devel:mariadb-libs"
    "libpq-fe.h:libpq-dev:postgresql-devel:postgresql-libs"
    "mongoc/mongoc.h:libmongoc-dev:mongo-c-driver-devel:mongo-c-driver"
    "hiredis/hiredis.h:libhiredis-dev:hiredis-devel:hiredis"
    "lmdb.h:liblmdb-dev:lmdb-devel:lmdb"
    "leveldb/db.h:libleveldb-dev:leveldb-devel:leveldb"

    # ── Réseau ────────────────────────────────────────────────────────────────
    "curl/curl.h:libcurl4-openssl-dev:libcurl-devel:curl"
    "microhttpd.h:libmicrohttpd-dev:libmicrohttpd-devel:libmicrohttpd"
    "event2/event.h:libevent-dev:libevent-devel:libevent"
    "uv.h:libuv1-dev:libuv-devel:libuv"
    "zmq.h:libzmq3-dev:zeromq-devel:zeromq"
    "amqp.h:librabbitmq-dev:librabbitmq-devel:rabbitmq-c"
    "nghttp2/nghttp2.h:libnghttp2-dev:libnghttp2-devel:nghttp2"
    "ssh.h:libssh-dev:libssh-devel:libssh"
    "ssh2.h:libssh2-1-dev:libssh2-devel:libssh2"
    "ldap.h:libldap2-dev:openldap-devel:libldap"
    "neon/ne_basic.h:libneon27-dev:neon-devel:neon"

    # ── Images / médias ───────────────────────────────────────────────────────
    "png.h:libpng-dev:libpng-devel:libpng"
    "jpeglib.h:libjpeg-dev:libjpeg-turbo-devel:libjpeg-turbo"
    "tiff.h:libtiff-dev:libtiff-devel:libtiff"
    "webp/encode.h:libwebp-dev:libwebp-devel:libwebp"
    "gif_lib.h:libgif-dev:giflib-devel:giflib"
    "Magick++.h:libmagick++-dev:ImageMagick-c++-devel:imagemagick"
    "SDL.h:libsdl1.2-dev:SDL-devel:sdl"
    "SDL2/SDL.h:libsdl2-dev:SDL2-devel:sdl2"
    "SDL2/SDL_image.h:libsdl2-image-dev:SDL2_image-devel:sdl2_image"
    "SDL2/SDL_mixer.h:libsdl2-mixer-dev:SDL2_mixer-devel:sdl2_mixer"
    "SDL2/SDL_ttf.h:libsdl2-ttf-dev:SDL2_ttf-devel:sdl2_ttf"
    "GL/gl.h:libgl-dev:mesa-libGL-devel:mesa"
    "GL/glu.h:libglu1-mesa-dev:mesa-libGLU-devel:glu"
    "GLFW/glfw3.h:libglfw3-dev:glfw-devel:glfw-x11"
    "glm/glm.hpp:libglm-dev:glm-devel:glm"
    "vulkan/vulkan.h:libvulkan-dev:vulkan-headers:vulkan-headers"
    "opencv2/core.hpp:libopencv-dev:opencv-devel:opencv"
    "libavcodec/avcodec.h:libavcodec-dev:ffmpeg-devel:ffmpeg"
    "libavformat/avformat.h:libavformat-dev:ffmpeg-devel:ffmpeg"
    "libswscale/swscale.h:libswscale-dev:ffmpeg-devel:ffmpeg"
    "portaudio.h:libportaudio2:portaudio-devel:portaudio"
    "alsa/asoundlib.h:libasound2-dev:alsa-lib-devel:alsa-lib"
    "ao/ao.h:libao-dev:libao-devel:libao"
    "sndfile.h:libsndfile1-dev:libsndfile-devel:libsndfile"
    "vorbis/codec.h:libvorbis-dev:libvorbis-devel:libvorbis"
    "FLAC/stream_decoder.h:libflac-dev:flac-devel:flac"

    # ── Sécurité / chiffrement ────────────────────────────────────────────────
    "gcrypt.h:libgcrypt20-dev:libgcrypt-devel:libgcrypt"
    "nettle/sha.h:nettle-dev:nettle-devel:nettle"
    "gpgme.h:libgpgme-dev:gpgme-devel:gpgme"

    # ── Polices / internationalisation ────────────────────────────────────────
    "fontconfig/fontconfig.h:libfontconfig1-dev:fontconfig-devel:fontconfig"
    "freetype2/freetype/freetype.h:libfreetype6-dev:freetype-devel:freetype2"
    "ft2build.h:libfreetype6-dev:freetype-devel:freetype2"
    "unicode/uchar.h:libicu-dev:libicu-devel:icu"
    "iconv.h:libc6-dev:glibc-devel:glibc"
    "readline/readline.h:libreadline-dev:readline-devel:readline"
    "ncurses.h:libncurses-dev:ncurses-devel:ncurses"
    "ncurses/ncurses.h:libncurses-dev:ncurses-devel:ncurses"
    "curses.h:libncurses-dev:ncurses-devel:ncurses"

    # ── Mathématiques / calcul ────────────────────────────────────────────────
    "fftw3.h:libfftw3-dev:fftw-devel:fftw"
    "gsl/gsl_math.h:libgsl-dev:gsl-devel:gsl"
    "lapacke.h:liblapacke-dev:lapack-devel:lapack"
    "cblas.h:libopenblas-dev:openblas-devel:openblas"
    "eigen3/Eigen/Core:libeigen3-dev:eigen3-devel:eigen"

    # ── Systèmes / noyau ─────────────────────────────────────────────────────
    "fuse.h:libfuse-dev:fuse-devel:fuse"
    "fuse3/fuse.h:libfuse3-dev:fuse3-devel:fuse3"
    "pcre.h:libpcre3-dev:pcre-devel:pcre"
    "pcre2.h:libpcre2-dev:pcre2-devel:pcre2"
    "dbus/dbus.h:libdbus-1-dev:dbus-devel:dbus"
    "gdbm.h:libgdbm-dev:gdbm-devel:gdbm"
    "tcl.h:tcl-dev:tcl-devel:tcl"
    "tk.h:tk-dev:tk-devel:tk"
    "lua.h:liblua5.3-dev:lua-devel:lua"
    "Python.h:python3-dev:python3-devel:python"
    "ruby.h:ruby-dev:ruby-devel:ruby"
    "jni.h:default-jdk:java-devel:jdk-openjdk"
    "boost/filesystem.hpp:libboost-filesystem-dev:boost-devel:boost"
    "boost/system.hpp:libboost-system-dev:boost-devel:boost"
    "boost/regex.hpp:libboost-regex-dev:boost-devel:boost"
    "boost/thread.hpp:libboost-thread-dev:boost-devel:boost"
    "boost/program_options.hpp:libboost-program-options-dev:boost-devel:boost"
    "fmt/core.h:libfmt-dev:fmt-devel:fmt"
    "spdlog/spdlog.h:libspdlog-dev:spdlog-devel:spdlog"
    "gtest/gtest.h:libgtest-dev:gtest-devel:gtest"
    "gmock/gmock.h:libgmock-dev:gmock-devel:gmock"

    # ── D-Bus / systèmes ──────────────────────────────────────────────────────
    "systemd/sd-daemon.h:libsystemd-dev:systemd-devel:systemd-libs"
    "udev/libudev.h:libudev-dev:libudev-devel:eudev"
    "blkid/blkid.h:libblkid-dev:libblkid-devel:util-linux"
    "mount.h:libmount-dev:libmount-devel:util-linux"
)

# =============================================================================
# FONCTIONS DE RECHERCHE
# =============================================================================

# Retourne le paquet correspondant à un en-tête ou fragment
# $1 = fragment (ex: "gtk/gtk.h" ou "gtk.h" ou "gtk")
# $2 = pm optionnel (apt/dnf/pacman) — défaut: apt
db_lookup_header() {
    local fragment="${1,,}"
    local pm="${2:-apt}"

    for entry in "${_DB_ENTRIES[@]}"; do
        IFS=':' read -r header deb fed arch <<< "$entry"
        if [[ "${header,,}" == *"${fragment}"* ]]; then
            case "$pm" in
                dnf|yum) echo "$fed"   ;;
                pacman)  echo "$arch"  ;;
                *)       echo "$deb"   ;;
            esac
            return 0
        fi
    done
    return 1
}

# Recherche par pkg-config name (ex: "gtk+-3.0")
db_lookup_pkgconfig() {
    local pc_name="${1,,}"
    local pm="${2:-apt}"

    # Correspondances pkg-config → entrées DB
    declare -A PC_MAP=(
        ["gtk+-3.0"]="gtk/gtk.h"
        ["gtk+-4.0"]="gtk4/gtk.h"
        ["glib-2.0"]="glib-2.0/glib.h"
        ["cairo"]="cairo/cairo.h"
        ["pango"]="pango/pango.h"
        ["libcurl"]="curl/curl.h"
        ["openssl"]="openssl/ssl.h"
        ["libxml-2.0"]="libxml/parser.h"
        ["sqlite3"]="sqlite3.h"
        ["zlib"]="zlib.h"
        ["libpng"]="png.h"
        ["sdl2"]="SDL2/SDL.h"
        ["gl"]="GL/gl.h"
        ["vulkan"]="vulkan/vulkan.h"
        ["freetype2"]="ft2build.h"
        ["libzmq"]="zmq.h"
        ["uuid"]="uuid/uuid.h"
        ["libuv"]="uv.h"
    )

    local header="${PC_MAP[$pc_name]}"
    if [[ -n "$header" ]]; then
        db_lookup_header "$header" "$pm"
        return $?
    fi
    return 1
}

# Sauvegarde une correspondance trouvée dynamiquement
db_save_dynamic() {
    local header="$1"
    local pkg="$2"
    local cache_file="${ATDP_DB_DIR}/dynamic_mappings.txt"
    mkdir -p "$ATDP_DB_DIR"
    grep -qF "${header}:${pkg}" "$cache_file" 2>/dev/null || \
        echo "${header}:${pkg}" >> "$cache_file"
}

# Charge les correspondances dynamiques
db_load_dynamic() {
    local cache_file="${ATDP_DB_DIR}/dynamic_mappings.txt"
    [[ -f "$cache_file" ]] || return 0
    while IFS=':' read -r header pkg; do
        [[ -z "$header" || -z "$pkg" ]] && continue
        log_debug "DB dynamique: $header → $pkg"
    done < "$cache_file"
}
