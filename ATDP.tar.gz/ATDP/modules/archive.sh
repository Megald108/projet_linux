#!/usr/bin/env bash
# =============================================================================
# ATDP - archive.sh
# Détection du format, validation et extraction des archives
# =============================================================================

# Répertoire d'extraction (défini dans atdp.sh)
ATDP_EXTRACT_DIR="${ATDP_EXTRACT_DIR:-${ATDP_TMP_DIR}/extract}"

# =============================================================================
# Phase 3 : Validation de l'archive locale
# =============================================================================
validate_archive() {
    local archive="$1"
    log_step "PHASE 3 : Validation de l'archive"

    if [[ ! -f "$archive" ]]; then
        log_error "Fichier introuvable : $archive"
        return 1
    fi

    if [[ ! -r "$archive" ]]; then
        log_error "Droits de lecture insuffisants : $archive"
        return 1
    fi

    if [[ ! -s "$archive" ]]; then
        log_error "L'archive est vide : $archive"
        return 1
    fi

    local size
    size="$(human_size "$archive")"
    log_info "Taille : $size"

    # Vérification de l'intégrité selon le format
    local fmt
    fmt="$(_detect_archive_format "$archive")"
    if [[ "$fmt" == "unknown" ]]; then
        log_error "Format d'archive non reconnu : $archive"
        file "$archive" | tee -a "$ATDP_LOG_FILE"
        return 1
    fi

    log_info "Format détecté : $fmt"

    case "$fmt" in
        tar.gz|tgz)   _test_tar "$archive" "-tzf"  ;;
        tar.bz2|tbz2) _test_tar "$archive" "-tjf"  ;;
        tar.xz|txz)   _test_tar "$archive" "-tJf"  ;;
        tar.lz|tlz)   _test_tar_lzip "$archive"     ;;
        tar)           _test_tar "$archive" "-tf"   ;;
        zip)           _test_zip "$archive"          ;;
        7z)            _test_7z  "$archive"          ;;
        gz)            _test_gz  "$archive"          ;;
        bz2)           _test_bz2 "$archive"          ;;
        xz)            _test_xz  "$archive"          ;;
    esac

    local ret=$?
    if [[ "$ret" -ne 0 ]]; then
        log_error "L'archive est corrompue ou invalide."
        return 1
    fi

    log_ok "Archive valide."
    export ATDP_ARCHIVE_FORMAT="$fmt"
    return 0
}

# =============================================================================
# Détection du format par extension PUIS par magic bytes
# =============================================================================
_detect_archive_format() {
    local file="$1"
    local name="${file,,}"

    # -- Par extension ---------------------------------------------------------
    if   [[ "$name" =~ \.tar\.gz$  ]]; then echo "tar.gz";  return; fi
    if   [[ "$name" =~ \.tgz$      ]]; then echo "tgz";     return; fi
    if   [[ "$name" =~ \.tar\.bz2$ ]]; then echo "tar.bz2"; return; fi
    if   [[ "$name" =~ \.tbz2?$    ]]; then echo "tbz2";    return; fi
    if   [[ "$name" =~ \.tar\.xz$  ]]; then echo "tar.xz";  return; fi
    if   [[ "$name" =~ \.txz$      ]]; then echo "txz";     return; fi
    if   [[ "$name" =~ \.tar\.lz$  ]]; then echo "tar.lz";  return; fi
    if   [[ "$name" =~ \.tar$      ]]; then echo "tar";     return; fi
    if   [[ "$name" =~ \.zip$      ]]; then echo "zip";     return; fi
    if   [[ "$name" =~ \.7z$       ]]; then echo "7z";      return; fi
    if   [[ "$name" =~ \.gz$       ]]; then echo "gz";      return; fi
    if   [[ "$name" =~ \.bz2$      ]]; then echo "bz2";     return; fi
    if   [[ "$name" =~ \.xz$       ]]; then echo "xz";      return; fi

    # -- Par magic bytes (file command) ----------------------------------------
    local mime type_info
    mime="$(file --mime-type -b "$file" 2>/dev/null)"
    type_info="$(file -b "$file" 2>/dev/null | tr '[:upper:]' '[:lower:]')"

    case "$mime" in
        application/x-tar)                echo "tar";     return ;;
        application/gzip)
            echo "$type_info" | grep -q "tar" && echo "tar.gz" || echo "gz"
            return ;;
        application/x-bzip2)
            echo "$type_info" | grep -q "tar" && echo "tar.bz2" || echo "bz2"
            return ;;
        application/x-xz)
            echo "$type_info" | grep -q "tar" && echo "tar.xz" || echo "xz"
            return ;;
        application/zip)                  echo "zip";     return ;;
        application/x-7z-compressed)     echo "7z";      return ;;
    esac

    echo "unknown"
}

# =============================================================================
# Phase 3 : Extraction
# =============================================================================
extract_archive() {
    local archive="$1"
    local fmt="${ATDP_ARCHIVE_FORMAT:-$(_detect_archive_format "$archive")}"
    log_step "PHASE 3 : Extraction ($fmt)"

    mkdir -p "$ATDP_EXTRACT_DIR"

    case "$fmt" in
        tar.gz|tgz)
            tar -xzf "$archive" -C "$ATDP_EXTRACT_DIR" 2>&1 | tee -a "$ATDP_LOG_FILE"
            ;;
        tar.bz2|tbz2)
            tar -xjf "$archive" -C "$ATDP_EXTRACT_DIR" 2>&1 | tee -a "$ATDP_LOG_FILE"
            ;;
        tar.xz|txz)
            tar -xJf "$archive" -C "$ATDP_EXTRACT_DIR" 2>&1 | tee -a "$ATDP_LOG_FILE"
            ;;
        tar.lz|tlz)
            if command_exists lzip; then
                lzip -d -c "$archive" | tar -x -C "$ATDP_EXTRACT_DIR" 2>&1 | tee -a "$ATDP_LOG_FILE"
            else
                log_warn "lzip non disponible — tentative via tar --lzip"
                tar --lzip -xf "$archive" -C "$ATDP_EXTRACT_DIR" 2>&1 | tee -a "$ATDP_LOG_FILE"
            fi
            ;;
        tar)
            tar -xf "$archive" -C "$ATDP_EXTRACT_DIR" 2>&1 | tee -a "$ATDP_LOG_FILE"
            ;;
        zip)
            unzip -q "$archive" -d "$ATDP_EXTRACT_DIR" 2>&1 | tee -a "$ATDP_LOG_FILE"
            ;;
        7z)
            if command_exists 7z; then
                7z x "$archive" -o"$ATDP_EXTRACT_DIR" 2>&1 | tee -a "$ATDP_LOG_FILE"
            elif command_exists 7za; then
                7za x "$archive" -o"$ATDP_EXTRACT_DIR" 2>&1 | tee -a "$ATDP_LOG_FILE"
            else
                log_error "p7zip non installé. Tentative d'installation..."
                install_package "p7zip-full" && \
                7z x "$archive" -o"$ATDP_EXTRACT_DIR" 2>&1 | tee -a "$ATDP_LOG_FILE"
            fi
            ;;
        gz)
            gunzip -c "$archive" > "${ATDP_EXTRACT_DIR}/$(basename "${archive%.gz}")" 2>&1
            ;;
        bz2)
            bunzip2 -c "$archive" > "${ATDP_EXTRACT_DIR}/$(basename "${archive%.bz2}")" 2>&1
            ;;
        xz)
            xz -d -c "$archive" > "${ATDP_EXTRACT_DIR}/$(basename "${archive%.xz}")" 2>&1
            ;;
        *)
            log_error "Format non supporté : $fmt"
            return 1
            ;;
    esac

    local ret=$?
    if [[ "$ret" -ne 0 ]]; then
        log_error "Extraction échouée (code $ret)."
        return 1
    fi

    log_ok "Extraction terminée dans : $ATDP_EXTRACT_DIR"
    return 0
}

# =============================================================================
# Phase 6 : Localise le dossier racine du projet (gère les archives imbriquées)
# =============================================================================
find_project_root() {
    local base="$ATDP_EXTRACT_DIR"
    log_step "PHASE 4 : Localisation du dossier projet"

    # Cas 1 : racine directe avec fichier de build
    if _has_build_file "$base"; then
        log_ok "Projet à la racine de l'extraction."
        export ATDP_PROJECT_DIR="$base"
        return 0
    fi

    # Cas 2 : un seul sous-dossier (cas le plus fréquent)
    local subdirs
    mapfile -t subdirs < <(find "$base" -maxdepth 1 -mindepth 1 -type d)
    if [[ ${#subdirs[@]} -eq 1 ]]; then
        if _has_build_file "${subdirs[0]}"; then
            log_ok "Projet détecté dans : ${subdirs[0]}"
            export ATDP_PROJECT_DIR="${subdirs[0]}"
            return 0
        fi
    fi

    # Cas 3 : recherche récursive
    local found
    found="$(find "$base" -maxdepth 4 \
        \( -name "configure" -o -name "CMakeLists.txt" \
           -o -name "meson.build" -o -name "Makefile" \
           -o -name "Cargo.toml" -o -name "go.mod" \
           -o -name "package.json" \) \
        -print -quit 2>/dev/null)"

    if [[ -n "$found" ]]; then
        local project_dir
        project_dir="$(dirname "$found")"
        log_ok "Projet trouvé dans : $project_dir"
        export ATDP_PROJECT_DIR="$project_dir"
        return 0
    fi

    # Cas 4 : fallback sur le premier sous-dossier
    if [[ ${#subdirs[@]} -ge 1 ]]; then
        log_warn "Aucun fichier de build trouvé. Utilisation du premier dossier : ${subdirs[0]}"
        export ATDP_PROJECT_DIR="${subdirs[0]}"
        return 0
    fi

    log_error "Impossible de localiser le dossier projet."
    return 1
}

_has_build_file() {
    local dir="$1"
    [[ -f "${dir}/configure"      ]] && return 0
    [[ -f "${dir}/configure.ac"   ]] && return 0
    [[ -f "${dir}/CMakeLists.txt" ]] && return 0
    [[ -f "${dir}/meson.build"    ]] && return 0
    [[ -f "${dir}/Makefile"       ]] && return 0
    [[ -f "${dir}/GNUmakefile"    ]] && return 0
    [[ -f "${dir}/Cargo.toml"     ]] && return 0
    [[ -f "${dir}/go.mod"         ]] && return 0
    [[ -f "${dir}/package.json"   ]] && return 0
    return 1
}

# =============================================================================
# Helpers de test d'intégrité
# =============================================================================
_test_tar()      { tar "$2" "$1" > /dev/null 2>&1; }
_test_tar_lzip() { lzip -t "$1" 2>/dev/null || tar --lzip -tf "$1" > /dev/null 2>&1; }
_test_zip()      { unzip -t "$1" > /dev/null 2>&1; }
_test_7z()       { 7z t "$1" > /dev/null 2>&1 || 7za t "$1" > /dev/null 2>&1; }
_test_gz()       { gunzip -t "$1" 2>/dev/null; }
_test_bz2()      { bunzip2 -t "$1" 2>/dev/null; }
_test_xz()       { xz -t "$1" 2>/dev/null; }
