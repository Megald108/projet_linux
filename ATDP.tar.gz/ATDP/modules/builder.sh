#!/usr/bin/env bash
# =============================================================================
# ATDP - builder.sh
# Détection du système de build, génération de configure, compilation
# =============================================================================

# Système détecté (export global)
ATDP_BUILD_SYSTEM=""
ATDP_BUILD_DIR=""

# =============================================================================
# Phase 4 : Détection automatique du système de build
# =============================================================================
detect_build_system() {
    local dir="$1"
    log_step "PHASE 5 : Détection du système de compilation"

    # Priorité : du plus spécifique au plus générique
    if   [[ -f "${dir}/meson.build"    ]]; then ATDP_BUILD_SYSTEM="meson"
    elif [[ -f "${dir}/CMakeLists.txt" ]]; then ATDP_BUILD_SYSTEM="cmake"
    elif [[ -f "${dir}/Cargo.toml"     ]]; then ATDP_BUILD_SYSTEM="cargo"
    elif [[ -f "${dir}/go.mod"         ]]; then ATDP_BUILD_SYSTEM="golang"
    elif [[ -f "${dir}/setup.py"       ]] || \
         [[ -f "${dir}/pyproject.toml" ]]; then ATDP_BUILD_SYSTEM="python"
    elif [[ -f "${dir}/package.json"   ]]; then ATDP_BUILD_SYSTEM="nodejs"
    elif [[ -f "${dir}/build.ninja"    ]]; then ATDP_BUILD_SYSTEM="ninja"
    elif [[ -f "${dir}/SConstruct"     ]]; then ATDP_BUILD_SYSTEM="scons"
    elif [[ -f "${dir}/autogen.sh"     ]]; then ATDP_BUILD_SYSTEM="autogen"
    elif [[ -f "${dir}/configure.ac"   ]] || \
         [[ -f "${dir}/configure.in"   ]]; then ATDP_BUILD_SYSTEM="autotools"
    elif [[ -f "${dir}/configure"      ]]; then ATDP_BUILD_SYSTEM="configure"
    elif [[ -f "${dir}/Makefile"       ]] || \
         [[ -f "${dir}/GNUmakefile"    ]]; then ATDP_BUILD_SYSTEM="make"
    else
        log_error "Aucun système de compilation reconnu dans : $dir"
        ls "$dir" | head -20 | tee -a "$ATDP_LOG_FILE"
        return 1
    fi

    log_ok "Système de compilation : $ATDP_BUILD_SYSTEM"
    export ATDP_BUILD_SYSTEM
    return 0
}

# =============================================================================
# Phase 5 : Assure que le système de build est installé
# =============================================================================
ensure_build_tools() {
    local bs="$ATDP_BUILD_SYSTEM"
    log_info "Vérification des outils de compilation pour : $bs"

    case "$bs" in
        meson|autogen|autotools)
            _ensure_tool "meson"        "meson"
            _ensure_tool "ninja"        "ninja-build"
            _ensure_tool "autoconf"     "autoconf"
            _ensure_tool "automake"     "automake"
            _ensure_tool "libtoolize"   "libtool"
            ;;
        cmake)
            _ensure_tool "cmake"  "cmake"
            _ensure_tool "make"   "make"
            ;;
        cargo)
            if ! command_exists cargo; then
                log_info "Installation de Rust via rustup..."
                if command_exists rustup; then
                    rustup update stable >> "$ATDP_LOG_FILE" 2>&1
                else
                    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y >> "$ATDP_LOG_FILE" 2>&1
                    # shellcheck disable=SC1090
                    source "$HOME/.cargo/env" 2>/dev/null || true
                fi
            fi
            ;;
        golang)
            _ensure_tool "go" "golang-go"
            ;;
        python)
            _ensure_tool "python3" "python3"
            _ensure_tool "pip3"    "python3-pip"
            ;;
        nodejs)
            _ensure_tool "node" "nodejs"
            _ensure_tool "npm"  "npm"
            ;;
        scons)
            _ensure_tool "scons" "scons"
            ;;
        make|configure|ninja)
            _ensure_tool "make" "make"
            _ensure_tool "gcc"  "gcc"
            ;;
    esac
    return 0
}

_ensure_tool() {
    local cmd="$1"
    local pkg="$2"
    if ! command_exists "$cmd"; then
        log_warn "$cmd absent — installation de $pkg..."
        update_pkg_index
        install_package "$pkg" >> "$ATDP_LOG_FILE" 2>&1 && log_ok "$cmd installé" || log_warn "Impossible d'installer $cmd"
    fi
}

# =============================================================================
# Phase 5 : Génération de ./configure (si configure.ac / autogen.sh)
# =============================================================================
generate_configure() {
    local dir="$1"
    cd "$dir" || return 1

    if [[ -f "./configure" ]]; then
        log_info "configure déjà présent — pas de regénération."
        return 0
    fi

    log_step "PHASE 5a : Génération de configure"

    if [[ -f "./autogen.sh" ]]; then
        log_info "Exécution de autogen.sh..."
        bash ./autogen.sh >> "$ATDP_LOG_FILE" 2>&1
    elif [[ -f "./configure.ac" || -f "./configure.in" ]]; then
        log_info "Exécution de autoreconf..."
        autoreconf -fi >> "$ATDP_LOG_FILE" 2>&1
    fi

    if [[ ! -f "./configure" ]]; then
        log_error "Impossible de générer configure."
        return 1
    fi
    log_ok "configure généré avec succès."
    return 0
}

# =============================================================================
# Phase 7 : Compilation
# =============================================================================
build_project() {
    local dir="$1"
    local cores
    cores="$(cpu_cores)"

    log_step "PHASE 7 : Compilation (${cores} cœur(s))"

    case "$ATDP_BUILD_SYSTEM" in
        meson)          _build_meson  "$dir" "$cores" ;;
        cmake)          _build_cmake  "$dir" "$cores" ;;
        cargo)          _build_cargo  "$dir" "$cores" ;;
        golang)         _build_go     "$dir" ;;
        python)         _build_python "$dir" ;;
        nodejs)         _build_nodejs "$dir" ;;
        scons)          _build_scons  "$dir" "$cores" ;;
        ninja)          _build_ninja  "$dir" "$cores" ;;
        autogen|autotools|configure|make)
                        _build_make   "$dir" "$cores" ;;
        *)
            log_error "Système de compilation non géré : $ATDP_BUILD_SYSTEM"
            return 1
            ;;
    esac

    return $?
}

# ── GNU Autotools / Make ──────────────────────────────────────────────────────
_build_make() {
    local dir="$1"; local cores="$2"
    cd "$dir" || return 1

    # Configuration si nécessaire
    if [[ "$ATDP_BUILD_SYSTEM" != "make" ]] && [[ -f "./configure" ]]; then
        log_info "  → ./configure"
        ./configure 2>&1 | tee -a "$ATDP_LOG_FILE"
        local ret="${PIPESTATUS[0]}"
        if [[ "$ret" -ne 0 ]]; then
            log_error "configure a échoué."
            return "$ret"
        fi
    fi

    log_info "  → make -j${cores}"
    make -j"${cores}" 2>&1 | tee -a "$ATDP_LOG_FILE"
    local ret="${PIPESTATUS[0]}"
    [[ "$ret" -ne 0 ]] && { log_error "make a échoué."; return "$ret"; }
    log_ok "Compilation réussie."
    return 0
}

# ── CMake ─────────────────────────────────────────────────────────────────────
_build_cmake() {
    local dir="$1"; local cores="$2"
    ATDP_BUILD_DIR="${dir}/build_atdp"
    mkdir -p "$ATDP_BUILD_DIR"
    cd "$ATDP_BUILD_DIR" || return 1

    log_info "  → cmake .."
    cmake .. -DCMAKE_BUILD_TYPE=Release 2>&1 | tee -a "$ATDP_LOG_FILE"
    local ret="${PIPESTATUS[0]}"
    [[ "$ret" -ne 0 ]] && { log_error "cmake a échoué."; return "$ret"; }

    log_info "  → make -j${cores}"
    make -j"${cores}" 2>&1 | tee -a "$ATDP_LOG_FILE"
    ret="${PIPESTATUS[0]}"
    [[ "$ret" -ne 0 ]] && { log_error "make (cmake) a échoué."; return "$ret"; }
    log_ok "Compilation CMake réussie."
    return 0
}

# ── Meson + Ninja ─────────────────────────────────────────────────────────────
_build_meson() {
    local dir="$1"; local cores="$2"
    ATDP_BUILD_DIR="${dir}/build_atdp"
    cd "$dir" || return 1

    log_info "  → meson setup build_atdp"
    meson setup "$ATDP_BUILD_DIR" 2>&1 | tee -a "$ATDP_LOG_FILE"
    local ret="${PIPESTATUS[0]}"
    [[ "$ret" -ne 0 ]] && { log_error "meson setup a échoué."; return "$ret"; }

    log_info "  → ninja -j${cores}"
    ninja -C "$ATDP_BUILD_DIR" -j"${cores}" 2>&1 | tee -a "$ATDP_LOG_FILE"
    ret="${PIPESTATUS[0]}"
    [[ "$ret" -ne 0 ]] && { log_error "ninja a échoué."; return "$ret"; }
    log_ok "Compilation Meson/Ninja réussie."
    return 0
}

# ── Cargo (Rust) ──────────────────────────────────────────────────────────────
_build_cargo() {
    local dir="$1"
    cd "$dir" || return 1
    # shellcheck disable=SC1090
    source "$HOME/.cargo/env" 2>/dev/null || true
    log_info "  → cargo build --release"
    cargo build --release 2>&1 | tee -a "$ATDP_LOG_FILE"
    local ret="${PIPESTATUS[0]}"
    [[ "$ret" -ne 0 ]] && { log_error "cargo build a échoué."; return "$ret"; }
    log_ok "Compilation Cargo réussie."
    return 0
}

# ── Go ────────────────────────────────────────────────────────────────────────
_build_go() {
    local dir="$1"
    cd "$dir" || return 1
    log_info "  → go build ./..."
    go build ./... 2>&1 | tee -a "$ATDP_LOG_FILE"
    local ret="${PIPESTATUS[0]}"
    [[ "$ret" -ne 0 ]] && { log_error "go build a échoué."; return "$ret"; }
    log_ok "Compilation Go réussie."
    return 0
}

# ── Python ────────────────────────────────────────────────────────────────────
_build_python() {
    local dir="$1"
    cd "$dir" || return 1
    log_info "  → python3 setup.py build / pip install"
    if [[ -f "pyproject.toml" ]]; then
        pip3 install . 2>&1 | tee -a "$ATDP_LOG_FILE"
    else
        python3 setup.py build 2>&1 | tee -a "$ATDP_LOG_FILE"
    fi
    local ret="${PIPESTATUS[0]}"
    [[ "$ret" -ne 0 ]] && { log_error "build Python a échoué."; return "$ret"; }
    log_ok "Build Python réussi."
    return 0
}

# ── Node.js ───────────────────────────────────────────────────────────────────
_build_nodejs() {
    local dir="$1"
    cd "$dir" || return 1
    log_info "  → npm install"
    npm install 2>&1 | tee -a "$ATDP_LOG_FILE"
    local ret="${PIPESTATUS[0]}"
    [[ "$ret" -ne 0 ]] && { log_error "npm install a échoué."; return "$ret"; }
    if grep -q '"build"' package.json 2>/dev/null; then
        log_info "  → npm run build"
        npm run build 2>&1 | tee -a "$ATDP_LOG_FILE"
    fi
    log_ok "Build Node.js réussi."
    return 0
}

# ── SCons ─────────────────────────────────────────────────────────────────────
_build_scons() {
    local dir="$1"; local cores="$2"
    cd "$dir" || return 1
    log_info "  → scons -j${cores}"
    scons -j"${cores}" 2>&1 | tee -a "$ATDP_LOG_FILE"
    local ret="${PIPESTATUS[0]}"
    [[ "$ret" -ne 0 ]] && { log_error "scons a échoué."; return "$ret"; }
    log_ok "Compilation SCons réussie."
    return 0
}

# ── Ninja seul ────────────────────────────────────────────────────────────────
_build_ninja() {
    local dir="$1"; local cores="$2"
    cd "$dir" || return 1
    log_info "  → ninja -j${cores}"
    ninja -j"${cores}" 2>&1 | tee -a "$ATDP_LOG_FILE"
    local ret="${PIPESTATUS[0]}"
    [[ "$ret" -ne 0 ]] && { log_error "ninja a échoué."; return "$ret"; }
    log_ok "Compilation Ninja réussie."
    return 0
}
