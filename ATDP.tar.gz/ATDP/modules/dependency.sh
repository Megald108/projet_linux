#!/usr/bin/env bash
# =============================================================================
# ATDP - dependency.sh
# Résolution intelligente des dépendances manquantes
# =============================================================================

ATDP_MAX_DEP_RETRIES="${ATDP_MAX_DEP_RETRIES:-8}"
ATDP_INSTALLED_DEPS=()

# =============================================================================
# Boucle principale de résolution automatique
# $1 = fonction de build (ex: "_build_make", "_run_configure")
# $2 = répertoire projet
# $3 = cores
# =============================================================================
resolve_and_build() {
    local build_fn="$1"
    local dir="$2"
    local cores="${3:-$(cpu_cores)}"
    local attempt=0

    while [[ "$attempt" -lt "$ATDP_MAX_DEP_RETRIES" ]]; do
        (( attempt++ ))
        log_info "Tentative de compilation #$attempt"

        # Appel de la fonction de build
        "$build_fn" "$dir" "$cores"
        local ret=$?
        [[ "$ret" -eq 0 ]] && return 0

        # En cas d'échec : lire les logs et tenter de résoudre
        log_warn "Échec (code $ret) — analyse des erreurs..."
        local resolved
        resolved="$(analyze_build_errors "$dir")"

        if [[ -z "$resolved" ]]; then
            log_error "Aucune dépendance identifiable dans les logs — abandon."
            return 1
        fi

        # Installer les paquets trouvés
        local installed_any=0
        while IFS= read -r pkg; do
            [[ -z "$pkg" ]] && continue
            if _is_already_installed "$pkg"; then
                log_debug "Paquet déjà installé : $pkg"
                continue
            fi
            log_info "Installation de la dépendance : $pkg"
            update_pkg_index
            if install_package "$pkg" >> "$ATDP_LOG_FILE" 2>&1; then
                log_ok "  ✔ $pkg installé"
                ATDP_INSTALLED_DEPS+=("$pkg")
                installed_any=1
                db_save_dynamic "$pkg" "$pkg"
            else
                log_warn "  ✘ Impossible d'installer $pkg"
            fi
        done <<< "$resolved"

        if [[ "$installed_any" -eq 0 ]]; then
            log_error "Aucune nouvelle dépendance installée — boucle infinie évitée. Abandon."
            return 1
        fi

        # Si configure existe, le relancer après installation des dépendances
        if [[ -f "${dir}/configure" && "$ATDP_BUILD_SYSTEM" != "make" ]]; then
            log_info "Relance de configure..."
            (cd "$dir" && ./configure >> "$ATDP_LOG_FILE" 2>&1) || true
        fi
    done

    log_error "Nombre maximum de tentatives atteint ($ATDP_MAX_DEP_RETRIES). Abandon."
    return 1
}

# =============================================================================
# Analyse les fichiers de log pour identifier les dépendances manquantes
# Retourne les noms de paquets sur stdout (un par ligne)
# =============================================================================
analyze_build_errors() {
    local dir="$1"
    local pm
    pm="$(detect_pkg_manager)"
    local found_pkgs=()

    # -- Sources de log à analyser ---------------------------------------------
    local log_files=(
        "${dir}/config.log"
        "${dir}/CMakeFiles/CMakeError.log"
        "${dir}/CMakeFiles/CMakeOutput.log"
        "${dir}/build_atdp/meson-logs/meson-log.txt"
        "${dir}/build_atdp/CMakeFiles/CMakeError.log"
        "$ATDP_LOG_FILE"
    )

    for lf in "${log_files[@]}"; do
        [[ -f "$lf" ]] || continue
        _parse_log_file "$lf" "$pm" found_pkgs
    done

    # Déduplique et affiche
    local -A seen=()
    for pkg in "${found_pkgs[@]}"; do
        [[ -z "$pkg" ]]          && continue
        [[ "${seen[$pkg]+x}" ]] && continue
        seen["$pkg"]=1
        echo "$pkg"
    done
}

# =============================================================================
# Analyse un fichier de log à la recherche de patterns connus
# $1=fichier, $2=pm, $3=nom de tableau (par référence nameref)
# =============================================================================
_parse_log_file() {
    local logfile="$1"
    local pm="$2"
    local -n _result_ref="$3"

    # -- Pattern 1 : fichier .h manquant : "fatal error: gtk/gtk.h: No such file" --
    while IFS= read -r header; do
        local pkg
        pkg="$(db_lookup_header "$header" "$pm")"
        if [[ -z "$pkg" ]]; then
            pkg="$(_apt_search_header "$header" "$pm")"
        fi
        [[ -n "$pkg" ]] && _result_ref+=("$pkg")
    done < <(grep -hioP '(?<=fatal error: )[^\s:]+\.h(?= |:)' "$logfile" 2>/dev/null | sort -u)

    # -- Pattern 2 : "error: gtk/gtk.h: No such file or directory" ──────────
    while IFS= read -r header; do
        local pkg
        pkg="$(db_lookup_header "$header" "$pm")"
        [[ -z "$pkg" ]] && pkg="$(_apt_search_header "$header" "$pm")"
        [[ -n "$pkg" ]] && _result_ref+=("$pkg")
    done < <(grep -hioP 'error: \K[^\s:]+\.h(?= |:)' "$logfile" 2>/dev/null | sort -u)

    # -- Pattern 3 : pkg-config "No package 'XXX' found" ---------------------
    while IFS= read -r pc; do
        local pkg
        pkg="$(db_lookup_pkgconfig "$pc" "$pm")"
        if [[ -z "$pkg" ]]; then
            pkg="$(_apt_search_pkgconfig "$pc" "$pm")"
        fi
        [[ -n "$pkg" ]] && _result_ref+=("$pkg")
    done < <(grep -hioP "No package '\K[^']+(?=' found)" "$logfile" 2>/dev/null | sort -u)

    # -- Pattern 4 : "Could not find XXX" (cmake) ---------------------------
    while IFS= read -r lib; do
        local pkg
        pkg="$(db_lookup_header "${lib,,}.h" "$pm")"
        [[ -z "$pkg" ]] && pkg="$(_apt_search_lib "$lib" "$pm")"
        [[ -n "$pkg" ]] && _result_ref+=("$pkg")
    done < <(grep -hioP 'Could not find \K\S+' "$logfile" 2>/dev/null | sort -u)

    # -- Pattern 5 : "library not found for -lXXX" / "cannot find -lXXX" ---
    while IFS= read -r lib; do
        local pkg
        pkg="$(_apt_search_lib "$lib" "$pm")"
        [[ -n "$pkg" ]] && _result_ref+=("$pkg")
    done < <(grep -hioP '(?:library not found for|cannot find) -l\K\S+' "$logfile" 2>/dev/null | sort -u)

    # -- Pattern 6 : "undefined reference to `XXX'" → chercher par symbole ---
    # (on skip : trop imprécis sans base de données des symboles)
}

# =============================================================================
# Recherche apt-file / apt-cache pour trouver le paquet fournissant un header
# =============================================================================
_apt_search_header() {
    local header="$1"
    local pm="$2"

    [[ "$pm" != "apt" ]] && return 1

    # apt-file search (précis mais nécessite apt-file installé)
    if command_exists apt-file; then
        local result
        result="$(apt-file search "$header" 2>/dev/null | grep -m1 '-dev:' | cut -d: -f1)"
        [[ -n "$result" ]] && echo "$result" && return 0
    fi

    # apt-cache search comme fallback
    local basename
    basename="$(basename "$header" .h)"
    local result
    result="$(apt-cache search "lib${basename}-dev" 2>/dev/null | head -1 | awk '{print $1}')"
    [[ -n "$result" ]] && echo "$result" && return 0

    return 1
}

_apt_search_pkgconfig() {
    local pc_name="$1"
    local pm="$2"
    [[ "$pm" != "apt" ]] && return 1

    # Pattern: libFOO-dev fournit souvent FOO.pc
    local clean="${pc_name//+/-}"   # gtk+-3.0 → gtk--3.0
    clean="${clean//[^a-zA-Z0-9-]/}"
    local result
    result="$(apt-cache search "${clean}" 2>/dev/null | grep '\-dev' | head -1 | awk '{print $1}')"
    [[ -n "$result" ]] && echo "$result" && return 0
    return 1
}

_apt_search_lib() {
    local lib="$1"
    local pm="$2"
    [[ "$pm" != "apt" ]] && return 1

    local candidates=("lib${lib}-dev" "lib${lib}1-dev" "lib${lib}2-dev" "lib${lib}3-dev")
    for c in "${candidates[@]}"; do
        if apt-cache show "$c" &>/dev/null; then
            echo "$c"
            return 0
        fi
    done

    local result
    result="$(apt-cache search "lib${lib}" 2>/dev/null | grep '\-dev' | head -1 | awk '{print $1}')"
    [[ -n "$result" ]] && echo "$result" && return 0
    return 1
}

# Vérifie si un paquet est déjà installé (Debian/Ubuntu)
_is_already_installed() {
    local pkg="$1"
    local pm
    pm="$(detect_pkg_manager)"
    case "$pm" in
        apt)    dpkg -l "$pkg" 2>/dev/null | grep -q '^ii' ;;
        dnf|yum) rpm -q "$pkg" &>/dev/null ;;
        pacman) pacman -Q "$pkg" &>/dev/null ;;
        *)      return 1 ;;
    esac
}
