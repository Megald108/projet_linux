#!/usr/bin/env bash
# =============================================================================
# ATDP - rollback.sh
# Désinstallation propre des logiciels installés par ATDP
#
# Principe :
#   - Chaque installation réussie est enregistrée dans une base de registre
#     (database/installed.txt) avec : nom, version, méthode, date,
#     répertoire projet d'origine, et liste des fichiers installés.
#   - Pour cargo / npm / go : on utilise les commandes natives de
#     désinstallation (cargo uninstall, npm uninstall -g, ...).
#   - Pour make / cmake / meson / autotools : on utilise soit
#     "make uninstall" si le projet le supporte, soit la liste des
#     fichiers enregistrés au moment de l'installation.
# =============================================================================

ATDP_REGISTRY_FILE="${ATDP_REGISTRY_FILE:-${ATDP_DB_DIR}/installed.txt}"
# Format d'une ligne du registre (séparateur "|||") :
# NOM|||VERSION|||METHODE|||DATE|||PROJET_DIR|||FICHIERS(separes par ":::")

# =============================================================================
# Enregistre une installation réussie dans le registre
# $1 = nom du logiciel
# $2 = version
# $3 = méthode (make/cmake/meson/cargo/golang/python/nodejs/scons/ninja)
# $4 = chemin du projet source (informatif)
# $5 = liste des fichiers installés, séparés par des sauts de ligne (peut être vide)
# =============================================================================
registry_record_install() {
    local name="$1"
    local version="$2"
    local method="$3"
    local project_dir="$4"
    local files_raw="$5"

    mkdir -p "$ATDP_DB_DIR"
    touch "$ATDP_REGISTRY_FILE"

    # Supprime un éventuel ancien enregistrement du même logiciel
    registry_remove_entry "$name" --silent

    # Convertit la liste de fichiers (un par ligne) en une chaîne séparée par ":::"
    local files_joined=""
    if [[ -n "$files_raw" ]]; then
        local sep
        sep="$(printf '\x1f')"
        files_joined="$(echo "$files_raw" | grep -v '^\s*$' | tr '\n' "$sep")"
        files_joined="${files_joined%$sep}"
    fi

    local date_str
    date_str="$(date '+%Y-%m-%d %H:%M:%S')"

    echo "${name}|||${version}|||${method}|||${date_str}|||${project_dir}|||${files_joined}" >> "$ATDP_REGISTRY_FILE"
    log_debug "Registre mis à jour pour : $name"
}

# =============================================================================
# Supprime une entrée du registre (sans désinstaller quoi que ce soit)
# $1 = nom, $2 = "--silent" optionnel pour ne pas logger
# =============================================================================
registry_remove_entry() {
    local name="$1"
    local silent="${2:-}"
    [[ -f "$ATDP_REGISTRY_FILE" ]] || return 0

    local tmp_file
    tmp_file="$(mktemp)"
    grep -v "^${name}|||" "$ATDP_REGISTRY_FILE" > "$tmp_file" 2>/dev/null || true
    mv "$tmp_file" "$ATDP_REGISTRY_FILE"

    [[ "$silent" != "--silent" ]] && log_debug "Entrée supprimée du registre : $name"
}

# =============================================================================
# Recherche une entrée dans le registre par nom (recherche insensible à la casse,
# correspondance partielle si aucune correspondance exacte)
# Retourne la ligne complète sur stdout, ou rien si non trouvé
# =============================================================================
registry_find_entry() {
    local name="$1"
    [[ -f "$ATDP_REGISTRY_FILE" ]] || return 1

    # Correspondance exacte d'abord
    local exact
    exact="$(grep -i "^${name}|||" "$ATDP_REGISTRY_FILE" | tail -1)"
    if [[ -n "$exact" ]]; then
        echo "$exact"
        return 0
    fi

    # Correspondance partielle ensuite
    local partial
    partial="$(grep -i "^[^|]*${name}[^|]*|||" "$ATDP_REGISTRY_FILE" | tail -1)"
    if [[ -n "$partial" ]]; then
        echo "$partial"
        return 0
    fi

    return 1
}

# =============================================================================
# Liste tous les logiciels installés via ATDP
# =============================================================================
list_installed() {
    log_title "Logiciels installés via ATDP"

    if [[ ! -f "$ATDP_REGISTRY_FILE" ]] || [[ ! -s "$ATDP_REGISTRY_FILE" ]]; then
        echo "  Aucun logiciel enregistré pour le moment."
        echo ""
        return 0
    fi

    printf "  %-20s %-12s %-12s %-20s\n" "NOM" "VERSION" "METHODE" "DATE D'INSTALLATION"
    printf "  %-20s %-12s %-12s %-20s\n" "---" "-------" "-------" "-------------------"

    while IFS='|||' read -r -a fields; do
        :
    done < /dev/null # no-op pour garder IFS local

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        local name version method date_str rest
        name="$(echo "$line"   | awk -F'\\|\\|\\|' '{print $1}')"
        version="$(echo "$line"| awk -F'\\|\\|\\|' '{print $2}')"
        method="$(echo "$line" | awk -F'\\|\\|\\|' '{print $3}')"
        date_str="$(echo "$line" | awk -F'\\|\\|\\|' '{print $4}')"
        printf "  %-20s %-12s %-12s %-20s\n" "$name" "$version" "$method" "$date_str"
    done < "$ATDP_REGISTRY_FILE"

    echo ""
}

# =============================================================================
# Point d'entrée principal : désinstalle un logiciel par son nom
# $1 = nom du logiciel (ou fragment de nom)
# =============================================================================
uninstall_software() {
    local query="$1"
    log_title "Désinstallation : $query"

    local entry
    if ! entry="$(registry_find_entry "$query")"; then
        log_error "Aucune entrée trouvée pour '$query' dans le registre ATDP."
        log_info "Utilisez --list-installed pour voir les logiciels enregistrés."
        return 1
    fi

    local name version method date_str project_dir files_joined
    name="$(echo "$entry"        | awk -F'\\|\\|\\|' '{print $1}')"
    version="$(echo "$entry"     | awk -F'\\|\\|\\|' '{print $2}')"
    method="$(echo "$entry"      | awk -F'\\|\\|\\|' '{print $3}')"
    date_str="$(echo "$entry"    | awk -F'\\|\\|\\|' '{print $4}')"
    project_dir="$(echo "$entry" | awk -F'\\|\\|\\|' '{print $5}')"
    files_joined="$(echo "$entry"| awk -F'\\|\\|\\|' '{print $6}')"

    echo ""
    log_info "Logiciel     : $name"
    log_info "Version      : $version"
    log_info "Méthode      : $method"
    log_info "Installé le  : $date_str"
    echo ""

    if [[ "${ATDP_YES:-0}" != "1" ]]; then
        if ! confirm "  Confirmer la désinstallation de '$name' ?"; then
            log_info "Désinstallation annulée."
            return 0
        fi
    fi

    local ret=0
    case "$method" in
        cargo)
            _uninstall_cargo "$name" || ret=1
            ;;
        nodejs)
            _uninstall_nodejs "$name" || ret=1
            ;;
        golang)
            _uninstall_golang "$name" || ret=1
            ;;
        python)
            _uninstall_python "$name" || ret=1
            ;;
        cmake|meson|ninja|make|configure|autotools|autogen|scons)
            _uninstall_via_files_or_make "$name" "$project_dir" "$files_joined" || ret=1
            ;;
        *)
            log_warn "Méthode inconnue ($method) — tentative via fichiers enregistrés."
            _uninstall_via_files_or_make "$name" "$project_dir" "$files_joined" || ret=1
            ;;
    esac

    if [[ "$ret" -eq 0 ]]; then
        registry_remove_entry "$name"
        log_ok "'$name' a été désinstallé et retiré du registre ATDP."
    else
        log_error "La désinstallation de '$name' a rencontré des problèmes."
        log_warn "L'entrée est conservée dans le registre pour référence."
    fi

    return "$ret"
}

# =============================================================================
# Désinstallation native : Cargo
# =============================================================================
_uninstall_cargo() {
    local name="$1"
    # shellcheck disable=SC1090
    source "$HOME/.cargo/env" 2>/dev/null || true

    if ! command_exists cargo; then
        log_error "cargo n'est pas disponible — impossible de désinstaller proprement."
        return 1
    fi

    log_info "  → cargo uninstall $name"
    cargo uninstall "$name" 2>&1 | tee -a "$ATDP_LOG_FILE"
    return "${PIPESTATUS[0]}"
}

# =============================================================================
# Désinstallation native : npm global
# =============================================================================
_uninstall_nodejs() {
    local name="$1"
    if ! command_exists npm; then
        log_error "npm n'est pas disponible — impossible de désinstaller proprement."
        return 1
    fi

    log_info "  → npm uninstall -g $name"
    run_privileged npm uninstall -g "$name" 2>&1 | tee -a "$ATDP_LOG_FILE"
    return "${PIPESTATUS[0]}"
}

# =============================================================================
# Désinstallation : Go (suppression manuelle du binaire dans GOPATH/bin)
# =============================================================================
_uninstall_golang() {
    local name="$1"
    local gopath_bin="${GOPATH:-$HOME/go}/bin"
    local bin_path="${gopath_bin}/${name}"

    if [[ -f "$bin_path" ]]; then
        log_info "  → suppression de $bin_path"
        rm -f "$bin_path"
        return 0
    fi

    log_warn "Binaire Go introuvable dans $gopath_bin — peut-être déjà supprimé."
    return 0
}

# =============================================================================
# Désinstallation : Python (pip uninstall)
# =============================================================================
_uninstall_python() {
    local name="$1"
    if ! command_exists pip3; then
        log_error "pip3 n'est pas disponible."
        return 1
    fi

    log_info "  → pip3 uninstall -y $name"
    run_privileged pip3 uninstall -y "$name" 2>&1 | tee -a "$ATDP_LOG_FILE"
    return "${PIPESTATUS[0]}"
}

# =============================================================================
# Désinstallation : make/cmake/meson/autotools
# Stratégie en cascade :
#   1. Si le projet source existe encore et propose "make uninstall", l'utiliser.
#   2. Sinon, utiliser la liste des fichiers enregistrés lors de l'installation.
#   3. Sinon, échec explicite avec conseils.
# =============================================================================
_uninstall_via_files_or_make() {
    local name="$1"
    local project_dir="$2"
    local files_joined="$3"

    # Stratégie 1 : make uninstall (si les sources sont conservées via --keep-src)
    if [[ -n "$project_dir" ]] && [[ -d "$project_dir" ]]; then
        if [[ -f "${project_dir}/Makefile" ]]; then
            local has_uninstall
            has_uninstall="$(grep -E '^uninstall:' "${project_dir}/Makefile" 2>/dev/null)"
            if [[ -n "$has_uninstall" ]]; then
                log_info "  → make uninstall (depuis $project_dir)"
                (cd "$project_dir" && run_privileged make uninstall 2>&1 | tee -a "$ATDP_LOG_FILE")
                return "${PIPESTATUS[0]}"
            fi
        fi
        # CMake : install_manifest.txt
        local manifest="${project_dir}/build_atdp/install_manifest.txt"
        if [[ -f "$manifest" ]]; then
            log_info "  → suppression via install_manifest.txt"
            _remove_files_from_manifest "$manifest"
            return $?
        fi
    fi

    # Stratégie 2 : fichiers enregistrés au moment de l'installation
    if [[ -n "$files_joined" ]]; then
        log_info "  → suppression des fichiers enregistrés lors de l'installation"
        local files=()
        IFS=$'\x1f' read -ra files <<< "$files_joined"
        _remove_file_list "${files[@]}"
        return $?
    fi

    # Stratégie 3 : échec — proposer une recherche manuelle
    log_error "Aucune méthode de désinstallation disponible pour '$name'."
    log_warn "Les sources ont probablement été nettoyées et aucun fichier n'a été enregistré."
    log_info "Vous pouvez chercher manuellement avec : which $name"
    log_info "Puis supprimer avec : sudo rm \$(which $name)"
    return 1
}

# Supprime les fichiers listés dans un install_manifest.txt (format CMake)
_remove_files_from_manifest() {
    local manifest="$1"
    local count=0
    local failed=0

    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        if [[ -f "$f" || -L "$f" ]]; then
            if run_privileged rm -f "$f" 2>>"$ATDP_LOG_FILE"; then
                (( count++ ))
                log_debug "  Supprimé : $f"
            else
                (( failed++ ))
                log_warn "  Échec suppression : $f"
            fi
        fi
    done < "$manifest"

    log_ok "$count fichier(s) supprimé(s)."
    [[ "$failed" -gt 0 ]] && log_warn "$failed fichier(s) n'ont pas pu être supprimés."
    return 0
}

# Supprime une liste de fichiers passés en arguments
_remove_file_list() {
    local count=0
    local failed=0

    for f in "$@"; do
        [[ -z "$f" ]] && continue
        if [[ -f "$f" || -L "$f" ]]; then
            if run_privileged rm -f "$f" 2>>"$ATDP_LOG_FILE"; then
                (( count++ ))
                log_debug "  Supprimé : $f"
            else
                (( failed++ ))
                log_warn "  Échec suppression : $f"
            fi
        else
            log_debug "  Déjà absent : $f"
        fi
    done

    log_ok "$count fichier(s) supprimé(s)."
    [[ "$failed" -gt 0 ]] && log_warn "$failed fichier(s) n'ont pas pu être supprimés."
    return 0
}
