#!/usr/bin/env bash
# =============================================================================
# ATDP - downloader.sh
# Téléchargement intelligent avec reprise, vérification et détection du nom
# =============================================================================

ATDP_CACHE_DIR="${ATDP_CACHE_DIR:-${ATDP_ROOT}/cache}"

# =============================================================================
# Valide l'URL (Phase 2 – mode URL)
# =============================================================================
validate_url() {
    local url="$1"
    log_step "PHASE 2 : Validation de l'URL"

    # Test de joignabilité (HEAD d'abord, puis GET limité)
    local http_code
    if command_exists curl; then
        http_code="$(curl -s -o /dev/null -L -w "%{http_code}" --max-time 15 --head "$url" 2>/dev/null)"
        # Certains serveurs refusent HEAD → fallback
        if [[ "$http_code" == "405" || "$http_code" == "000" ]]; then
            http_code="$(curl -s -o /dev/null -L -w "%{http_code}" --max-time 15 --range 0-0 "$url" 2>/dev/null)"
        fi
    elif command_exists wget; then
        wget -q --spider --timeout=15 --tries=2 "$url" 2>/dev/null && http_code="200" || http_code="000"
    else
        log_error "ni curl ni wget disponibles."
        return 1
    fi

    case "$http_code" in
        200|206|301|302|303|307|308)
            log_ok "URL accessible (HTTP $http_code)"
            return 0
            ;;
        404)
            log_error "Ressource introuvable (HTTP 404) : $url"
            return 1
            ;;
        403)
            log_error "Accès refusé (HTTP 403) : $url"
            return 1
            ;;
        000)
            log_error "Aucune réponse du serveur : $url"
            return 1
            ;;
        *)
            log_warn "Code HTTP inattendu : $http_code — tentative de téléchargement quand même."
            return 0
            ;;
    esac
}

# =============================================================================
# Déduit le nom du fichier depuis une URL
# =============================================================================
_filename_from_url() {
    local url="$1"
    # Retire les paramètres GET et ancres
    local base
    base="$(basename "${url%%\?*}" | sed 's/#.*//')"
    # Décode %XX
    printf '%b' "${base//%/\\x}"
}

# =============================================================================
# Téléchargement avec reprise
# $1 = URL
# $2 = répertoire de destination (optionnel, défaut: ATDP_TMP_DIR)
# Écrit le chemin final dans ATDP_ARCHIVE_PATH
# =============================================================================
download_archive() {
    local url="$1"
    local dest_dir="${2:-${ATDP_TMP_DIR}}"
    mkdir -p "$dest_dir"

    local filename
    filename="$(_filename_from_url "$url")"

    # Si le nom ne ressemble pas à une archive, on utilise un nom générique
    if ! echo "$filename" | grep -qiE '\.(tar|gz|xz|bz2|zip|tgz|txz|7z|lz|lzip)'; then
        # Tente de récupérer le Content-Disposition
        local cd_name
        cd_name="$(curl -sI -L "$url" 2>/dev/null | grep -i 'content-disposition' | grep -oP 'filename="?\K[^";\s]+' || true)"
        if [[ -n "$cd_name" ]]; then
            filename="$cd_name"
        else
            filename="archive_atdp"
        fi
    fi

    local dest_file="${dest_dir}/${filename}"

    log_step "PHASE 2 : Téléchargement"
    log_info "  URL      : $url"
    log_info "  Fichier  : $dest_file"

    if command_exists curl; then
        curl -L \
             --retry 3 \
             --retry-delay 5 \
             --continue-at - \
             --progress-bar \
             --output "$dest_file" \
             "$url" 2>&1 | tee -a "$ATDP_LOG_FILE"
        local ret="${PIPESTATUS[0]}"
    elif command_exists wget; then
        wget \
             --tries=3 \
             --waitretry=5 \
             --continue \
             --show-progress \
             --output-document="$dest_file" \
             "$url" 2>&1 | tee -a "$ATDP_LOG_FILE"
        local ret="${PIPESTATUS[0]}"
    else
        log_error "Aucun outil de téléchargement disponible (curl / wget)."
        return 1
    fi

    if [[ "$ret" -ne 0 ]]; then
        log_error "Téléchargement échoué (code $ret)."
        return 1
    fi

    if [[ ! -s "$dest_file" ]]; then
        log_error "Fichier téléchargé vide ou inexistant : $dest_file"
        return 1
    fi

    log_ok "Téléchargement terminé : $(human_size "$dest_file")"

    # Vérifier que ce n'est pas une page HTML d'erreur
    local mime
    mime="$(file --mime-type -b "$dest_file" 2>/dev/null)"
    if [[ "$mime" == "text/html" ]]; then
        log_error "Le fichier téléchargé semble être une page HTML (erreur serveur ?)."
        log_error "Contenu : $(head -3 "$dest_file")"
        return 1
    fi

    ATDP_ARCHIVE_PATH="$dest_file"
    return 0
}

# =============================================================================
# Vérification SHA256 (optionnel)
# $1 = fichier, $2 = somme attendue
# =============================================================================
verify_checksum() {
    local file="$1"
    local expected="$2"
    [[ -z "$expected" ]] && return 0

    log_info "Vérification SHA256..."
    local actual
    actual="$(sha256sum "$file" 2>/dev/null | awk '{print $1}')"
    if [[ "$actual" == "$expected" ]]; then
        log_ok "SHA256 valide"
        return 0
    else
        log_error "SHA256 invalide !"
        log_error "  Attendu : $expected"
        log_error "  Obtenu  : $actual"
        return 1
    fi
}
