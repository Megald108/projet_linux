# ATDP — Automatic Tarball Deployment Platform v4

Installe automatiquement un logiciel depuis son code source (archive `.tar.gz`, `.tar.xz`, `.zip`, etc.) **sans que l'utilisateur ait besoin de connaître** `make`, `cmake`, `configure`, `meson`, `apt` ou `pkg-config`.

---

## Installation rapide

```bash
git clone <ce dépôt> ATDP
cd ATDP
chmod +x atdp.sh
./atdp.sh
```

---

## Utilisation

### Mode interactif (menu)
```bash
./atdp.sh
```

### Archive locale
```bash
./atdp.sh --file /chemin/vers/archive.tar.xz
```

### Téléchargement depuis Internet
```bash
./atdp.sh --url https://ftp.gnu.org/gnu/wget/wget-1.21.4.tar.gz
```

### Options complètes
```
--url <URL>         Télécharger l'archive depuis cette URL
--file <ARCHIVE>    Utiliser une archive locale
--yes               Pas de confirmation interactive
--debug             Mode verbeux (DEBUG)
--keep-src          Conserve le dossier source après installation
--keep-archive      Conserve l'archive téléchargée
--no-install        Compile sans installer
--sha256 <HASH>     Vérifie le SHA256 de l'archive avant extraction
--uninstall <NOM>   Désinstalle un logiciel précédemment installé par ATDP
--list-installed    Liste les logiciels installés via ATDP
--help              Affiche l'aide
```

### Désinstallation

ATDP enregistre automatiquement chaque installation réussie dans un registre interne (`database/installed.txt`). Pour désinstaller :

```bash
./atdp.sh --list-installed
./atdp.sh --uninstall ripgrep
```

La stratégie de désinstallation dépend du système de build d'origine :

| Méthode d'installation | Stratégie de désinstallation                          |
|-------------------------|--------------------------------------------------------|
| Cargo (Rust)             | `cargo uninstall <nom>` (natif)                        |
| npm (Node.js)            | `npm uninstall -g <nom>` (natif)                       |
| pip (Python)             | `pip3 uninstall -y <nom>` (natif)                      |
| Go                       | Suppression du binaire dans `$GOPATH/bin`               |
| Make / Autotools / CMake | `make uninstall` si disponible, sinon suppression des fichiers enregistrés lors de l'installation (extraits automatiquement de la sortie de `make install` / `cmake --install`) |

---

## Systèmes de build supportés

| Fichier détecté       | Système          | Commandes utilisées                          |
|-----------------------|------------------|----------------------------------------------|
| `meson.build`         | Meson + Ninja    | `meson setup` → `ninja` → `ninja install`   |
| `CMakeLists.txt`      | CMake            | `cmake ..` → `make` → `cmake --install`     |
| `Cargo.toml`          | Cargo (Rust)     | `cargo build --release` → `cargo install`   |
| `go.mod`              | Go               | `go build ./...` → `go install ./...`       |
| `setup.py` / `pyproject.toml` | Python  | `pip3 install .` ou `setup.py install`      |
| `package.json`        | Node.js          | `npm install` → `npm run build`             |
| `SConstruct`          | SCons            | `scons` → `scons install`                   |
| `autogen.sh`          | GNU Autotools    | `autogen.sh` → `configure` → `make install` |
| `configure.ac`        | GNU Autotools    | `autoreconf -fi` → `configure` → `make install` |
| `configure`           | Configure        | `./configure` → `make` → `make install`     |
| `Makefile`            | Make             | `make -j$(nproc)` → `make install`         |

---

## Architecture des fichiers

```
ATDP/
├── atdp.sh                  Programme principal
├── modules/
│   ├── logger.sh            Journalisation horodatée (INFO/WARN/ERROR/DEBUG)
│   ├── utils.sh             Outils génériques (sudo, distro, install_package)
│   ├── database.sh          Table header → paquet (300+ entrées)
│   ├── detector.sh          Phase 0 : vérification de l'environnement
│   ├── menu.sh              Interface utilisateur interactive
│   ├── downloader.sh        Téléchargement avec reprise (curl/wget)
│   ├── archive.sh           Détection de format, validation, extraction
│   ├── builder.sh           Détection du build system, compilation
│   ├── dependency.sh        Résolution automatique des dépendances
│   ├── installer.sh         Installation + extraction de la liste des fichiers
│   ├── rollback.sh          Registre des installations + désinstallation propre
│   ├── cleanup.sh           Nettoyage des fichiers temporaires
│   └── report.sh            Rapport final
├── config/
│   └── atdp.conf            Configuration par défaut
├── cache/                   Cache des métadonnées
├── logs/                    Journaux de session
├── tmp/                     Fichiers temporaires de session
└── database/                Correspondances dynamiques apprises
```

---

## Résolution automatique des dépendances

ATDP analyse les erreurs de compilation pour identifier les bibliothèques manquantes :

- Erreurs `fatal error: XXX.h: No such file` → recherche dans la base de données interne (300+ en-têtes connus) puis via `apt-cache` / `apt-file`
- Messages `No package 'XXX' found` (pkg-config) → résolution pkg-config
- Messages `Could not find XXX` (CMake) → résolution CMake
- Messages `cannot find -lXXX` (linker) → recherche dans les paquets `-dev`

En cas d'échec, ATDP installe le paquet, puis relance automatiquement la compilation (jusqu'à 8 tentatives par défaut).

---

## Formats d'archives supportés

`.tar.gz` `.tgz` `.tar.xz` `.txz` `.tar.bz2` `.tbz2` `.tar.lz` `.tar` `.zip` `.7z` `.gz` `.bz2` `.xz`

---

## Distributions Linux supportées

| Distribution          | Gestionnaire |
|-----------------------|--------------|
| Ubuntu / Debian / Mint / Kali / Raspberry Pi OS | `apt` |
| Fedora / RHEL / CentOS / Rocky / AlmaLinux | `dnf` / `yum` |
| Arch Linux / Manjaro / EndeavourOS | `pacman` |
| openSUSE | `zypper` |

---

## Exemples d'utilisation

```bash
# Compiler et installer vim depuis l'archive officielle
./atdp.sh --url https://github.com/vim/vim/archive/v9.1.tar.gz

# Installer wget depuis l'archive locale
./atdp.sh --file ~/téléchargements/wget-1.21.4.tar.gz --yes

# Compiler sans installer (tests)
./atdp.sh --url https://example.com/mylib.tar.gz --no-install

# Mode debug pour diagnostiquer un problème
./atdp.sh --file ./projet.tar.gz --debug --keep-src
```
