#!/usr/bin/env bash
# =============================================================================
#   ATDP — Automatic Tarball Deployment Platform  v4
#   Programme principal
#
#   Usage :
#     ./atdp.sh                     # mode interactif
#     ./atdp.sh --url <URL>         # téléchargement non interactif
#     ./atdp.sh --file <ARCHIVE>    # archive locale non interactive
#     ./atdp.sh --yes               # pas de confirmation
#     ./atdp.sh --keep-src          # conserve les sources après install
#     ./atdp.sh --keep-archive      # conserve l'archive téléchargée
#     ./atdp.sh --debug             # mode debug verbeux
#     ./atdp.sh --no-install        # compile sans installer
#     ./atdp.sh --sha256 <HASH>     # vérifie le SHA256 de l'archive
#     ./atdp.sh --help
# =============================================================================
set -euo pipefail
IFS=$'\n\t'

# ── Répertoire racine d'ATDP (toujours absolu) ────────────────────────────────
ATDP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export ATDP_ROOT

# ── Répertoires de travail ────────────────────────────────────────────────────
ATDP_TMP_DIR="${ATDP_ROOT}/tmp/session_$$"
ATDP_EXTRACT_DIR="${ATDP_TMP_DIR}/extract"
ATDP_LOG_DIR="${ATDP_ROOT}/logs"
ATDP_LOG_FILE="${ATDP_LOG_DIR}/atdp_$(date '+%Y%m%d_%H%M%S')_$$.log"
ATDP_DB_DIR="${ATDP_ROOT}/database"
ATDP_CACHE_DIR="${ATDP_ROOT}/cache"
export ATDP_TMP_DIR ATDP_EXTRACT_DIR ATDP_LOG_FILE ATDP_DB_DIR ATDP_CACHE_DIR

# ── Variables globales de session ─────────────────────────────────────────────
ATDP_INPUT_MODE=""      # "local" ou "url"
ATDP_ARCHIVE_PATH=""
ATDP_ARCHIVE_URL=""
ATDP_PROJECT_DIR=""
ATDP_BUILD_SYSTEM=""
ATDP_BUILD_DIR=""
ATDP_START_TIME="$(date +%s)"
ATDP_INSTALLED_DEPS=()
ATDP_INSTALLED_VERSION=""

# Options utilisateur
ATDP_YES="${ATDP_YES:-0}"
ATDP_DEBUG="${ATDP_DEBUG:-0}"
ATDP_KEEP_SRC="${ATDP_KEEP_SRC:-0}"
ATDP_KEEP_ARCHIVE="${ATDP_KEEP_ARCHIVE:-0}"
ATDP_NO_INSTALL="${ATDP_NO_INSTALL:-0}"
ATDP_SHA256=""

# Mode spécial (désinstallation / liste) — défini par les arguments CLI
ATDP_ACTION="install"   # "install" | "uninstall" | "list"
ATDP_UNINSTALL_TARGET=""

# ── Chargement des modules ────────────────────────────────────────────────────
_load_module() {
    local mod="${ATDP_ROOT}/modules/${1}"
    if [[ ! -f "$mod" ]]; then
        echo "[ERREUR] Module introuvable : $mod" >&2
        exit 1
    fi
    # shellcheck disable=SC1090
    source "$mod"
}

_load_module logger.sh
_load_module utils.sh
_load_module database.sh
_load_module detector.sh
_load_module menu.sh
_load_module downloader.sh
_load_module archive.sh
_load_module builder.sh
_load_module dependency.sh
_load_module installer.sh
_load_module rollback.sh
_load_module cleanup.sh
_load_module report.sh

# ── Trap : nettoyage sur interruption ────────────────────────────────────────
_session_exit_code=0
trap '_on_exit' EXIT
trap '_on_interrupt' INT TERM

_on_interrupt() {
    echo ""
    log_warn "Signal d'interruption reçu."
    emergency_cleanup
    generate_report 1
    exit 130
}

_on_exit() {
    local code=$?
    # Nettoyage silencieux uniquement si le script a fini normalement
    [[ "$code" -ne 0 ]] && true
}

# =============================================================================
# Parsing des arguments en ligne de commande
# =============================================================================
_parse_args() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --url|-u)
                ATDP_ARCHIVE_URL="$2"
                ATDP_INPUT_MODE="url"
                shift 2
                ;;
            --file|-f)
                ATDP_ARCHIVE_PATH="$2"
                ATDP_INPUT_MODE="local"
                shift 2
                ;;
            --yes|-y)
                ATDP_YES=1
                shift
                ;;
            --debug|-d)
                ATDP_DEBUG=1
                ATDP_LOG_LEVEL="DEBUG"
                shift
                ;;
            --keep-src)
                ATDP_KEEP_SRC=1
                shift
                ;;
            --keep-archive)
                ATDP_KEEP_ARCHIVE=1
                shift
                ;;
            --no-install)
                ATDP_NO_INSTALL=1
                shift
                ;;
            --sha256)
                ATDP_SHA256="$2"
                shift 2
                ;;
            --uninstall)
                ATDP_ACTION="uninstall"
                ATDP_UNINSTALL_TARGET="$2"
                shift 2
                ;;
            --list-installed)
                ATDP_ACTION="list"
                shift
                ;;
            --help|-h)
                _show_help
                exit 0
                ;;
            *)
                echo "Option inconnue : $1"
                _show_help
                exit 1
                ;;
        esac
    done
}

_show_help() {
    cat << 'EOF'
ATDP — Automatic Tarball Deployment Platform v4

Usage:
  ./atdp.sh [OPTIONS]

Options:
  --url <URL>        Télécharger l'archive depuis cette URL
  --file <ARCHIVE>   Utiliser une archive locale
  --yes              Pas de confirmation interactive
  --debug            Mode verbeux
  --keep-src         Conserve le dossier source après installation
  --keep-archive     Conserve l'archive téléchargée
  --no-install       Compile sans installer (make install ignoré)
  --sha256 <HASH>    Vérifie le SHA256 de l'archive
  --uninstall <NOM>  Désinstalle un logiciel précédemment installé par ATDP
  --list-installed   Liste les logiciels installés via ATDP
  --help             Affiche cette aide

Exemples:
  ./atdp.sh --file ~/téléchargements/vim.tar.xz --yes
  ./atdp.sh --url https://ftp.gnu.org/gnu/wget/wget-1.21.4.tar.gz
  ./atdp.sh --url https://example.com/lib.tar.xz --sha256 abc123...
  ./atdp.sh --list-installed
  ./atdp.sh --uninstall ripgrep
EOF
}

# =============================================================================
# PROGRAMME PRINCIPAL
# =============================================================================
main() {
    _parse_args "$@"

    # Prépare les répertoires et le journal
    mkdir -p "$ATDP_TMP_DIR" "$ATDP_EXTRACT_DIR" "$ATDP_LOG_DIR" \
             "$ATDP_DB_DIR"  "$ATDP_CACHE_DIR"
    log_init

    # ── Modes spéciaux : désinstallation / liste ────────────────────────────
    # Ces modes ne lancent pas le pipeline d'installation complet.
    if [[ "$ATDP_ACTION" == "list" ]]; then
        show_banner
        list_installed
        exit 0
    fi

    if [[ "$ATDP_ACTION" == "uninstall" ]]; then
        show_banner
        if uninstall_software "$ATDP_UNINSTALL_TARGET"; then
            exit 0
        else
            exit 1
        fi
    fi

    show_banner

    # ── PHASE 0 : Vérification de l'environnement ──────────────────────────
    if ! check_environment; then
        generate_report 1
        exit 1
    fi

    # ── PHASE 1 : Choix du mode (menu ou ligne de commande) ────────────────
    if [[ -z "$ATDP_INPUT_MODE" ]]; then
        log_step "PHASE 1 : Choix du mode"
        menu_main
    fi

    # ── PHASE 2 : Validation / Téléchargement ──────────────────────────────
    if [[ "$ATDP_INPUT_MODE" == "url" ]]; then
        if ! validate_url "$ATDP_ARCHIVE_URL"; then
            generate_report 1; exit 1
        fi
        if ! download_archive "$ATDP_ARCHIVE_URL"; then
            generate_report 1; exit 1
        fi
    else
        log_step "PHASE 2 : Validation de l'archive locale"
        log_info "Archive : $ATDP_ARCHIVE_PATH"
    fi

    # Vérification SHA256 optionnelle
    if [[ -n "$ATDP_SHA256" ]]; then
        if ! verify_checksum "$ATDP_ARCHIVE_PATH" "$ATDP_SHA256"; then
            generate_report 1; exit 1
        fi
    fi

    # ── PHASE 3 : Validation et extraction ────────────────────────────────
    if ! validate_archive "$ATDP_ARCHIVE_PATH"; then
        generate_report 1; exit 1
    fi
    if ! extract_archive "$ATDP_ARCHIVE_PATH"; then
        generate_report 1; exit 1
    fi

    # ── PHASE 4 : Localisation du projet ──────────────────────────────────
    if ! find_project_root; then
        generate_report 1; exit 1
    fi

    # ── PHASE 5 : Détection du système de build ────────────────────────────
    if ! detect_build_system "$ATDP_PROJECT_DIR"; then
        generate_report 1; exit 1
    fi

    # S'assurer que les outils nécessaires sont installés
    ensure_build_tools

    # Confirmation avant compilation
    if ! menu_confirm_start; then
        log_info "Installation annulée par l'utilisateur."
        cleanup_workspace
        exit 0
    fi

    # ── PHASE 5a : Génération de configure (si nécessaire) ─────────────────
    if [[ "$ATDP_BUILD_SYSTEM" == "autotools" || "$ATDP_BUILD_SYSTEM" == "autogen" ]]; then
        if ! generate_configure "$ATDP_PROJECT_DIR"; then
            generate_report 1; exit 1
        fi
        # Après génération de configure, traiter comme configure classique
        ATDP_BUILD_SYSTEM="configure"
    fi

    # ── PHASES 6-7 : Résolution des dépendances + Compilation ───────────────
    log_step "PHASES 6-7 : Résolution des dépendances et compilation"

    # Choisir la bonne fonction de build selon le système détecté
    local build_fn
    case "$ATDP_BUILD_SYSTEM" in
        cmake)         build_fn="_build_cmake"  ;;
        meson)         build_fn="_build_meson"  ;;
        cargo)         build_fn="_build_cargo"  ;;
        golang)        build_fn="_build_go"     ;;
        python)        build_fn="_build_python" ;;
        nodejs)        build_fn="_build_nodejs" ;;
        scons)         build_fn="_build_scons"  ;;
        ninja)         build_fn="_build_ninja"  ;;
        *)             build_fn="_build_make"   ;;  # autotools / configure / make
    esac

    if ! resolve_and_build "$build_fn" "$ATDP_PROJECT_DIR" "$(cpu_cores)"; then
        log_error "La compilation a échoué après résolution des dépendances."
        generate_report 1
        cleanup_workspace
        exit 1
    fi

    # ── PHASE 8 : Vérification post-compilation ────────────────────────────
    verify_build "$ATDP_PROJECT_DIR"

    # ── PHASE 9 : Installation ─────────────────────────────────────────────
    if [[ "$ATDP_NO_INSTALL" != "1" ]]; then
        if ! install_project "$ATDP_PROJECT_DIR"; then
            log_error "L'installation a échoué."
            generate_report 1
            cleanup_workspace
            exit 1
        fi
    else
        log_warn "Installation ignorée (--no-install)."
    fi

    # ── PHASE 10 : Vérification finale ────────────────────────────────────
    verify_installation "$ATDP_PROJECT_DIR" || true

    # ── Enregistrement dans le registre ATDP (pour désinstallation future) ──
    if [[ "$ATDP_NO_INSTALL" != "1" ]]; then
        local sw_name sw_version
        sw_name="$(basename "$ATDP_PROJECT_DIR" | sed 's/[-_][0-9].*//')"
        sw_version="$(basename "$ATDP_PROJECT_DIR" | grep -oP '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -1 || true)"
        [[ -z "$sw_version" ]] && sw_version="inconnue"

        registry_record_install \
            "$sw_name" \
            "$sw_version" \
            "$ATDP_BUILD_SYSTEM" \
            "$ATDP_PROJECT_DIR" \
            "$ATDP_INSTALLED_FILES_LIST" || true

        log_info "Enregistré dans le registre ATDP (désinstallable via --uninstall $sw_name)"
    fi

    # ── PHASE 11 : Nettoyage ──────────────────────────────────────────────
    cleanup_workspace

    # ── PHASE 12 : Rapport ────────────────────────────────────────────────
    generate_report 0

    exit 0
}

# Lancement
main "$@"
