# `atdp.sh` — Le script principal

## Rôle dans le projet

C'est le **seul fichier que l'utilisateur exécute directement** (`./atdp.sh`). Contrairement aux autres modules qui contiennent chacun une logique métier précise (télécharger, extraire, compiler...), `atdp.sh` ne fait **aucun travail lui-même** — il se contente d'organiser dans le bon ordre les fonctions définies ailleurs. C'est ce qu'on appelle un rôle d' **orchestrateur** : il sait *quoi* faire et *dans quel ordre*, mais délègue systématiquement le *comment* aux modules.

Le fichier se découpe en 6 grandes parties, dans cet ordre précis : les réglages de sécurité, la définition des chemins et variables, le chargement des modules, la gestion des interruptions, le traitement des arguments de la ligne de commande, et enfin la fonction `main()` qui exécute réellement les 12 phases.

---

## Partie 1 — Les réglages de sécurité en tout début de fichier

```bash
#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'
```

**`#!/usr/bin/env bash`** — C'est ce qu'on appelle un "shebang". Cette ligne, obligatoirement la toute première du fichier, dit au système d'exploitation quel interpréteur utiliser pour exécuter ce fichier quand on le lance directement (`./atdp.sh`). Plutôt que d'écrire `#!/bin/bash` (un chemin fixe qui suppose que bash est installé exactement à cet endroit), la forme `#!/usr/bin/env bash` demande au système de chercher `bash` dans le `PATH` — plus portable, car certains systèmes (notamment certains environnements macOS ou NixOS) installent bash à un autre emplacement.

**`set -e`** — Cette option change fondamentalement le comportement de tout le script. Par défaut, Bash continue d'exécuter les lignes suivantes même si une commande échoue. Avec `set -e` activé, **le script s'arrête immédiatement** dès qu'une commande retourne un code différent de zéro (sauf dans certains contextes précis, comme à l'intérieur d'un test `if` ou après un `||`). C'est ce mécanisme qui a été à l'origine de plusieurs bugs rencontrés et corrigés pendant le développement du projet — par exemple, un `grep -oP` qui ne trouve aucune correspondance retourne le code 1, ce qui suffisait à tuer tout le script sans message d'erreur clair, avant qu'on ajoute des `|| true` aux endroits sensibles.

**`set -u`** — Fait planter le script si une variable **non définie** est utilisée. C'est une protection contre les fautes de frappe silencieuses : sans cette option, écrire `$ATPD_ROOT` au lieu de `$ATDP_ROOT` (une faute de frappe) donnerait simplement une chaîne vide sans avertissement, ce qui pourrait provoquer des comportements incohérents difficiles à diagnostiquer bien plus tard dans l'exécution.

**`set -o pipefail`** — Change la façon dont Bash calcule le code de retour d'un pipe (`commande1 | commande2`). Par défaut, seul le code de retour de la **dernière** commande du pipe compte. Avec `pipefail`, si **n'importe laquelle** des commandes du pipe échoue, le code de retour global du pipe reflète cet échec. C'est complémentaire du mécanisme `PIPESTATUS` utilisé ailleurs dans le projet — `pipefail` influence le comportement automatique de `set -e` sur les pipes, alors que `PIPESTATUS` permet d'inspecter manuellement chaque code individuellement quand on a besoin de plus de précision.

**`IFS=$'\n\t'`** — `IFS` (Internal Field Separator) est la variable qui dit à Bash comment découper du texte en mots séparés (par exemple lors d'une boucle `for mot in $texte`). Par défaut, `IFS` contient l'espace, la tabulation et le retour à la ligne — les trois à la fois. En la restreignant ici à seulement la tabulation et le retour à la ligne (`$'\n\t'`, où `$'...'` permet d'écrire des caractères spéciaux comme `\n`), on empêche Bash de découper accidentellement un chemin de fichier contenant des espaces (comme `/home/user/Mes Documents/archive.tar.gz`) en plusieurs "mots" distincts lors d'opérations non protégées par des guillemets. C'est une précaution de sécurité supplémentaire, complémentaire (mais pas substituable) au bon réflexe de toujours mettre les variables entre guillemets (`"$variable"`).

---

## Partie 2 — Chemins et variables globales de session

```bash
ATDP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export ATDP_ROOT
```

Cette ligne calcule le **chemin absolu** du dossier contenant `atdp.sh`, peu importe d'où l'utilisateur lance le script. `${BASH_SOURCE[0]}` est une variable spéciale de Bash qui contient le chemin du script en cours d'exécution (potentiellement relatif, comme `./atdp.sh` ou `../ATDP/atdp.sh`). `dirname` en extrait le dossier parent. Le `cd ... && pwd` est l'astuce classique pour transformer un chemin relatif en chemin absolu : on se déplace réellement dans ce dossier, puis `pwd` (print working directory) affiche le chemin complet et non ambigu depuis la racine du système de fichiers.

Cette variable est absolument fondamentale : **tous** les autres chemins du script (modules, cache, logs, base de données) sont construits à partir d'elle, ce qui rend ATDP utilisable depuis n'importe quel dossier de travail, sans jamais supposer que l'utilisateur se trouve dans un dossier précis avant de lancer la commande.

```bash
ATDP_TMP_DIR="${ATDP_ROOT}/tmp/session_$$"
ATDP_EXTRACT_DIR="${ATDP_TMP_DIR}/extract"
ATDP_LOG_FILE="${ATDP_LOG_DIR}/atdp_$(date '+%Y%m%d_%H%M%S')_$$.log"
```

**`$$`** est une autre variable spéciale de Bash : le PID (identifiant de processus) du script en cours d'exécution, attribué par le système d'exploitation. L'utiliser dans le nom du dossier temporaire (`session_$$`) garantit que **deux lancements simultanés d'ATDP** (par exemple si l'utilisateur ouvre deux terminaux et lance le script dans chacun) ne se marchent jamais dessus en utilisant accidentellement le même dossier de travail — chaque processus a un PID unique.

Le nom du fichier journal combine la date (`date '+%Y%m%d_%H%M%S'`, donnant par exemple "20260702_051200") et le PID, pour produire un nom de fichier à la fois lisible chronologiquement et garanti unique.

```bash
ATDP_INPUT_MODE=""
ATDP_ARCHIVE_PATH=""
ATDP_BUILD_SYSTEM=""
ATDP_INSTALLED_DEPS=()
```

Ce bloc déclare, avec des valeurs vides ou des tableaux vides, toutes les variables qui seront **remplies plus tard par les modules**. C'est une pratique de bonne hygiène en programmation : déclarer explicitement toutes les variables globales au même endroit, même vides, plutôt que de les laisser apparaître pour la première fois n'importe où dans le code — ça donne une vue d'ensemble immédiate de ce que le script va manipuler comme état partagé entre modules.

```bash
ATDP_YES="${ATDP_YES:-0}"
ATDP_DEBUG="${ATDP_DEBUG:-0}"
```

Ce motif `${VAR:-valeur_defaut}`, déjà rencontré dans plusieurs modules, permet ici quelque chose de subtil : ces variables peuvent être définies **avant** même le lancement du script, directement dans l'environnement shell (par exemple `ATDP_YES=1 ./atdp.sh`), et dans ce cas la valeur existante est conservée. Sinon, une valeur par défaut de "0" est utilisée. C'est ce qui permet à la fois l'usage normal via les options `--yes`/`--debug` (traitées plus loin par `_parse_args`) et un usage plus avancé via des variables d'environnement, sans conflit entre les deux méthodes.

---

## Partie 3 — Le système de chargement des modules

```bash
_load_module() {
    local mod="${ATDP_ROOT}/modules/${1}"
    if [[ ! -f "$mod" ]]; then
        echo "[ERREUR] Module introuvable : $mod" >&2
        exit 1
    fi
    source "$mod"
}

_load_module logger.sh
_load_module utils.sh
_load_module database.sh
_load_module detector.sh
_load_module menu.sh
_load_module downloader.sh
_load_module archive.sh
_load_module builder.sh
_load_module dependency.sh
_load_module installer.sh
_load_module rollback.sh
_load_module cleanup.sh
_load_module report.sh
```

**`echo "..." >&2`** — Le `>&2` redirige ce message d'erreur vers la sortie d'erreur standard (le flux numéro 2) plutôt que la sortie normale (flux numéro 1, utilisée par défaut par `echo`). C'est une convention Unix universelle : les messages d'erreur doivent aller sur la sortie d'erreur, pas la sortie normale — ça permet par exemple à l'utilisateur de rediriger séparément les résultats normaux et les erreurs (`./atdp.sh > resultats.txt 2> erreurs.txt`), ou à d'autres programmes qui appelleraient ATDP de distinguer facilement les deux flux.

**Pourquoi cette vérification d'existence avant `source` ?** Sans elle, si un module manquait (fichier supprimé par erreur, mauvaise installation), Bash produirait une erreur cryptique du type "No such file or directory" pointant vers la commande `source` elle-même, sans dire clairement quel module manque ni où chercher. Cette vérification explicite transforme une erreur confuse en message clair et actionnable.

**L'ordre des 13 appels à `_load_module` n'est pas arbitraire** — chaque module ne peut utiliser que les fonctions des modules déjà chargés avant lui. `logger.sh` et `utils.sh` sont chargés en tout premier car ce sont les deux seuls modules dont **tous** les autres dépendent. `database.sh` précède `dependency.sh` qui en a besoin. `installer.sh` précède `rollback.sh`, qui a besoin d'accéder à certaines de ses variables.

---

## Partie 4 — Gestion des interruptions avec `trap`

```bash
trap '_on_exit' EXIT
trap '_on_interrupt' INT TERM

_on_interrupt() {
    echo ""
    log_warn "Signal d'interruption reçu."
    emergency_cleanup
    generate_report 1
    exit 130
}

_on_exit() {
    local code=$?
    [[ "$code" -ne 0 ]] && true
}
```

`trap` est un mécanisme Bash qui intercepte les **signaux** envoyés par le système d'exploitation à un processus en cours d'exécution. Un signal est une façon pour le système (ou pour l'utilisateur) de communiquer un événement à un programme sans passer par ses entrées normales.

**`INT`** correspond au signal envoyé quand l'utilisateur appuie sur Ctrl+C dans le terminal (INT pour "interrupt"). **`TERM`** est un signal de demande d'arrêt plus général, souvent envoyé par le système lors d'un arrêt propre de la machine ou par la commande `kill` sans option particulière. Sans ce `trap`, un Ctrl+C en pleine extraction d'archive laisserait des fichiers temporaires éparpillés dans `tmp/`, sans jamais nettoyer proprement.

**`exit 130`** — Ce n'est pas un nombre choisi au hasard : par convention Unix, le code de sortie d'un processus tué par un signal est `128 + numéro_du_signal`. Le signal INT porte le numéro 2, donc `128 + 2 = 130`. Respecter cette convention permet à d'autres outils qui examineraient le code de sortie d'ATDP de comprendre précisément que le programme a été interrompu par l'utilisateur, et non qu'il a échoué normalement.

**`trap '_on_exit' EXIT`** est différent des deux autres : le "signal" `EXIT` n'est pas un vrai signal système, c'est un événement spécial de Bash qui se déclenche **à chaque fois que le script se termine, peu importe la raison** (succès normal, `exit` explicite avec n'importe quel code, ou même après un des deux autres traps). C'est un filet de sécurité final, garanti de s'exécuter dans presque tous les cas de figure.

---

## Partie 5 — Traitement des arguments de la ligne de commande

```bash
_parse_args() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --url|-u)
                ATDP_ARCHIVE_URL="$2"
                ATDP_INPUT_MODE="url"
                shift 2
                ;;
            --yes|-y)
                ATDP_YES=1
                shift
                ;;
            --uninstall)
                ATDP_ACTION="uninstall"
                ATDP_UNINSTALL_TARGET="$2"
                shift 2
                ;;
            --help|-h)
                _show_help
                exit 0
                ;;
            *)
                echo "Option inconnue : $1"
                _show_help
                exit 1
                ;;
        esac
    done
}
```

**`while [[ $# -gt 0 ]]; do`** — `$#` est une variable spéciale contenant le **nombre d'arguments restants** à traiter. Cette boucle continue tant qu'il reste au moins un argument non traité — une fois tous les arguments consommés (via `shift`), `$#` devient 0 et la boucle s'arrête naturellement.

**La différence entre `shift` et `shift 2`** — Rencontrée déjà dans `logger.sh` sous sa forme simple, ici on voit sa variante avec un nombre. `shift` seul décale les arguments d'une position (équivalent à `shift 1`). `shift 2` décale de deux positions d'un coup — nécessaire pour les options qui attendent une **valeur** juste après elles (comme `--url https://...`, où `$1` est `--url` et `$2` est l'URL elle-même) : après avoir traité les deux ensemble, il faut avancer de deux crans pour arriver au prochain vrai argument (ou à la fin).

**Pourquoi `*)` (le cas par défaut) affiche une erreur plutôt que d'ignorer silencieusement** — C'est un choix de robustesse : si l'utilisateur tape par erreur `--fil` au lieu de `--file` (faute de frappe), le script s'arrête immédiatement avec un message clair plutôt que de continuer silencieusement avec des valeurs par défaut potentiellement incorrectes, ce qui serait bien plus difficile à diagnostiquer.

---

## Partie 6 — La fonction `main()`, cœur de l'orchestration

```bash
main() {
    _parse_args "$@"

    mkdir -p "$ATDP_TMP_DIR" "$ATDP_EXTRACT_DIR" "$ATDP_LOG_DIR" \
             "$ATDP_DB_DIR"  "$ATDP_CACHE_DIR"
    log_init
```

**`"$@"`** transmet **tous** les arguments reçus par le script (préservés individuellement, contrairement à `"$*"`) à la fonction `_parse_args`. C'est ce mécanisme qui permet à `./atdp.sh --file archive.tar.gz --yes --debug` de fonctionner : les trois arguments (plus leurs éventuelles valeurs) sont transmis intacts.

```bash
    if [[ "$ATDP_ACTION" == "list" ]]; then
        show_banner
        list_installed
        exit 0
    fi

    if [[ "$ATDP_ACTION" == "uninstall" ]]; then
        show_banner
        if uninstall_software "$ATDP_UNINSTALL_TARGET"; then
            exit 0
        else
            exit 1
        fi
    fi

    show_banner
```

Ce bloc illustre un **aiguillage précoce** (early branching) : si l'utilisateur a demandé `--list-installed` ou `--uninstall`, le programme ne suit **jamais** le pipeline normal des 12 phases d'installation — il exécute la fonction correspondante puis quitte immédiatement (`exit 0` ou `exit 1`). C'est plus simple et plus sûr que d'essayer d'insérer ces cas spéciaux au milieu du pipeline normal avec de multiples conditions à chaque étape.

```bash
    if ! check_environment; then
        generate_report 1
        exit 1
    fi

    if [[ -z "$ATDP_INPUT_MODE" ]]; then
        log_step "PHASE 1 : Choix du mode"
        menu_main
    fi
```

**`if ! check_environment; then ... fi`** — Le `!` inverse le résultat du test : si `check_environment` **échoue** (retourne un code différent de 0), on génère un rapport d'échec et on quitte. C'est le motif utilisé de façon quasi-systématique dans tout le reste de `main()` pour chaque phase : chaque fonction est appelée, son échec éventuel est immédiatement détecté et traité, avant de continuer vers la phase suivante.

**`if [[ -z "$ATDP_INPUT_MODE" ]]; then menu_main; fi`** — Ce test vérifie si `ATDP_INPUT_MODE` est encore vide. Il ne l'est **que si** l'utilisateur n'a fourni ni `--url` ni `--file` en ligne de commande (ces options, traitées dans `_parse_args`, remplissent directement cette variable). Si l'utilisateur a déjà précisé son intention via la ligne de commande, le menu interactif est **sauté entièrement** — c'est ce qui permet à ATDP de fonctionner aussi bien en mode interactif qu'en mode totalement scriptable/automatisé.

```bash
    if [[ "$ATDP_INPUT_MODE" == "url" ]]; then
        if ! validate_url "$ATDP_ARCHIVE_URL"; then
            generate_report 1; exit 1
        fi
        if ! download_archive "$ATDP_ARCHIVE_URL"; then
            generate_report 1; exit 1
        fi
    else
        log_step "PHASE 2 : Validation de l'archive locale"
        log_info "Archive : $ATDP_ARCHIVE_PATH"
    fi
```

Ce `if/else` illustre bien le principe énoncé dès le début du projet ("le reste du moteur est exactement identique, seule l'origine de l'archive change") : après ce bloc, peu importe si l'archive vient d'un téléchargement ou d'un fichier local, la variable `ATDP_ARCHIVE_PATH` contient le chemin vers un fichier local existant, et **toutes les phases suivantes** (validation, extraction, compilation...) sont rigoureusement identiques dans les deux cas — aucune duplication de logique entre les deux modes.

```bash
    if [[ "$ATDP_BUILD_SYSTEM" == "autotools" || "$ATDP_BUILD_SYSTEM" == "autogen" ]]; then
        if ! generate_configure "$ATDP_PROJECT_DIR"; then
            generate_report 1; exit 1
        fi
        ATDP_BUILD_SYSTEM="configure"
    fi
```

Ce passage montre une **réaffectation intentionnelle** d'une variable globale en cours de route : une fois que `generate_configure` a produit avec succès un fichier `configure` à partir de `configure.ac` ou `autogen.sh`, on change volontairement `ATDP_BUILD_SYSTEM` pour la valeur `"configure"`, de sorte que tout le reste du pipeline (notamment le `case` qui choisit la fonction de compilation, juste après) traite ce projet exactement comme s'il avait fourni un `configure` prêt à l'emploi dès le départ — évitant ainsi de dupliquer la logique de compilation pour ces cas.

```bash
    local build_fn
    case "$ATDP_BUILD_SYSTEM" in
        cmake)  build_fn="_build_cmake"  ;;
        cargo)  build_fn="_build_cargo"  ;;
        *)      build_fn="_build_make"   ;;
    esac

    if ! resolve_and_build "$build_fn" "$ATDP_PROJECT_DIR" "$(cpu_cores)"; then
        log_error "La compilation a échoué après résolution des dépendances."
        generate_report 1
        cleanup_workspace
        exit 1
    fi
```

Ce `case` choisit le **nom** (sous forme de texte) de la fonction de compilation appropriée, sans jamais l'exécuter directement ici — c'est `resolve_and_build` (dans `dependency.sh`) qui se chargera de l'appeler réellement, potentiellement plusieurs fois de suite si des dépendances manquantes doivent être installées entre chaque tentative. `atdp.sh` délègue ainsi complètement la logique de retry à un autre module, se contentant de déterminer quelle fonction utiliser.

```bash
    if [[ "$ATDP_NO_INSTALL" != "1" ]]; then
        local sw_name sw_version
        sw_name="$(basename "$ATDP_PROJECT_DIR" | sed 's/[-_][0-9].*//')"
        sw_version="$(basename "$ATDP_PROJECT_DIR" | grep -oP '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -1 || true)"
        [[ -z "$sw_version" ]] && sw_version="inconnue"

        registry_record_install \
            "$sw_name" "$sw_version" "$ATDP_BUILD_SYSTEM" \
            "$ATDP_PROJECT_DIR" "$ATDP_INSTALLED_FILES_LIST" || true
    fi
```

Ce bloc contient la correction d'un bug réel rencontré en testant le projet : `grep -oP ... || true` — le `|| true` a été ajouté après avoir découvert qu'un dossier de projet sans numéro de version dans son nom (comme simplement "htop" plutôt que "htop-3.4.1") faisait échouer `grep -oP` (aucune correspondance trouvée, code de retour 1), ce qui — combiné à `set -e` actif — tuait tout le script silencieusement juste après une installation pourtant réussie. Le `|| true` neutralise cet échec non-critique en le transformant systématiquement en succès (code 0), permettant au script de continuer normalement même quand aucune version n'a pu être extraite du nom de dossier.

```bash
    generate_report 0
    exit 0
}

main "$@"
```

La toute dernière ligne du fichier, `main "$@"`, est ce qui déclenche réellement toute l'exécution. Sans cet appel final, la fonction `main` serait bien définie mais ne s'exécuterait jamais — c'est une convention courante en Bash de définir toutes les fonctions d'abord, puis de terminer le script par l'appel explicite de la fonction principale, une structure qui rend le fichier plus facile à lire de haut en bas (on voit d'abord "comment" avant de voir "on lance").

---

## Vue d'ensemble : `atdp.sh` comme point de convergence

Ce fichier ne contient jamais plus de deux ou trois lignes de vraie logique métier à la suite — son rôle est exclusivement de **enchaîner des appels à des fonctions définies ailleurs**, en vérifiant systématiquement leur succès avant de continuer. C'est cette discipline (chaque étape vérifiée, chaque échec traité immédiatement, jamais de supposition qu'une étape a réussi) qui rend le pipeline de 12 phases fiable : si quelque chose échoue n'importe où, l'utilisateur reçoit un rapport clair (`generate_report 1`) plutôt qu'un plantage silencieux ou un enchaînement d'erreurs en cascade.
