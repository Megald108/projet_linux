#!/usr/bin/env bash
# =============================================================================
# ATDP - installer.sh
# Phase 8-10 : vérification post-build, installation, vérification finale
# =============================================================================

ATDP_INSTALLED_BINARIES=()
ATDP_INSTALLED_FILES_LIST=""   # rempli par install_project(), utilisé par rollback.sh

# =============================================================================
# Phase 8 : Vérification post-compilation
# =============================================================================
verify_build() {
    local dir="$1"
    log_step "PHASE 8 : Vérification post-compilation"

    # Cherche les binaires produits (ELF exécutables)
    local bins=()

    # Cargo : target/release/ en priorité (exclut les build-scripts)
    if [[ -d "${dir}/target/release" ]]; then
        mapfile -t bins < <(find "${dir}/target/release" -maxdepth 1 -type f \
            -executable ! -name '*.d' ! -name 'build_script*' ! -name '*-*' \
            2>/dev/null | head -10)
    fi

    # Autres systèmes de build
    if [[ ${#bins[@]} -eq 0 ]]; then
        mapfile -t bins < <(find "$dir" -maxdepth 6 -type f \
            ! -path '*/.git/*' \
            ! -path '*/CMakeFiles/*' \
            ! -path '*/target/build/*' \
            ! -name '*.o' ! -name '*.a' ! -name '*.so*' \
            -executable 2>/dev/null | head -20)
    fi

    if [[ ${#bins[@]} -eq 0 ]]; then
        log_warn "Aucun exécutable trouvé après compilation — peut être normal (lib, Python, Node)."
    else
        log_info "Exécutables produits :"
        for b in "${bins[@]}"; do
            file "$b" 2>/dev/null | grep -q ELF && log_info "  • $(basename "$b")"
        done
    fi

    log_ok "Vérification post-compilation terminée."
    return 0
}

# =============================================================================
# Extrait les chemins de fichiers installés depuis la sortie de "make install"
# (ou équivalent) — repère les lignes du type :
#   /usr/bin/install -c fichier '/usr/local/bin'
#   /usr/bin/install -c -m 644 fichier '/usr/local/share/...'
# Retourne un chemin complet par ligne sur stdout.
# =============================================================================
_extract_installed_files_from_log() {
    local logfile="$1"

    # Approche : reconstruire chemin complet = dest_dir + basename(source)
    grep -P "^\s*/usr/bin/install\s" "$logfile" 2>/dev/null | while IFS= read -r line; do
        # Le dernier champ entre quotes est le répertoire de destination
        local dest_dir
        dest_dir="$(echo "$line" | grep -oP "'\K[^']+(?=')" | tail -1)"
        [[ -z "$dest_dir" ]] && continue

        # Le fichier source est l'avant-dernier token avant le répertoire de destination
        # On extrait tous les tokens non-option, le source est juste avant la destination
        local source_file
        source_file="$(echo "$line" | sed -E "s/'[^']*'$//" | awk '{print $NF}')"
        [[ -z "$source_file" ]] && continue

        echo "${dest_dir%/}/$(basename "$source_file")"
    done

    # Pattern CMake : "-- Installing: /chemin/complet"
    grep -oP -- '-- Installing:\s*\K\S+' "$logfile" 2>/dev/null

    # Pattern CMake (symlinks) : "-- Up-to-date: /chemin"
    grep -oP -- '-- Up-to-date:\s*\K\S+' "$logfile" 2>/dev/null
}

# =============================================================================
# Phase 9 : Installation
# =============================================================================
install_project() {
    local dir="$1"
    log_step "PHASE 9 : Installation"

    # Renouvelle le ticket sudo avant l'installation
    # (la compilation peut avoir duré longtemps et expiré le ticket)
    if ! is_root; then
        log_info "  Renouvellement des droits sudo..."
        sudo -v 2>/dev/null || log_warn "sudo -v a échoué — le mot de passe sera demandé"
    fi

    local install_log
    install_log="$(mktemp)"
    local ret=0

    case "$ATDP_BUILD_SYSTEM" in
        meson)
            log_info "  → ninja install (meson)"
            run_privileged ninja -C "${ATDP_BUILD_DIR:-${dir}/build_atdp}" install 2>&1 | tee -a "$ATDP_LOG_FILE" "$install_log"
            ret="${PIPESTATUS[0]}"
            ;;
        cmake)
            log_info "  → cmake --install"
            run_privileged cmake --install "${ATDP_BUILD_DIR:-${dir}/build_atdp}" 2>&1 | tee -a "$ATDP_LOG_FILE" "$install_log"
            ret="${PIPESTATUS[0]}"
            ;;
        cargo)
            log_info "  → copie des binaires Cargo compilés"
            # shellcheck disable=SC1090
            source "$HOME/.cargo/env" 2>/dev/null || true

            local release_dir="${dir}/target/release"
            local installed_count=0

            if [[ ! -d "$release_dir" ]]; then
                log_error "Dossier target/release introuvable : $release_dir"
                ret=1
            else
                # Cherche les vrais binaires ELF (exclut build-scripts et fichiers intermédiaires)
                while IFS= read -r bin; do
                    local bin_name
                    bin_name="$(basename "$bin")"
                    log_info "  Copie : $bin_name → /usr/local/bin/"
                    local install_out
                    install_out="$(sudo install -m 755 "$bin" "/usr/local/bin/${bin_name}" 2>&1)"
                    local install_ret=$?
                    [[ -n "$install_out" ]] && echo "$install_out" >> "$ATDP_LOG_FILE"
                    if [[ "$install_ret" -eq 0 ]]; then
                        (( installed_count++ ))
                        log_ok "$bin_name installé dans /usr/local/bin/"
                    else
                        log_error "Échec de la copie de $bin_name : $install_out"
                        ret=1
                        break
                    fi
                done < <(find "$release_dir" -maxdepth 1 -type f \
                    ! -name '*.d' ! -name '*.rlib' ! -name '*.rmeta' \
                    2>/dev/null | while IFS= read -r f; do
                        file "$f" 2>/dev/null | grep -q "ELF.*executable" && echo "$f"
                    done)

                if [[ "$installed_count" -eq 0 && "$ret" -eq 0 ]]; then
                    log_error "Aucun binaire ELF trouvé dans $release_dir"
                    ls -la "$release_dir" | head -20 >> "$ATDP_LOG_FILE"
                    ret=1
                fi
            fi
            ;;
        golang)
            log_info "  → go install"
            (cd "$dir" && go install ./... 2>&1 | tee -a "$ATDP_LOG_FILE" "$install_log")
            ret="${PIPESTATUS[0]}"
            ;;
        python)
            log_info "  → pip3 install / python3 setup.py install"
            if [[ -f "${dir}/pyproject.toml" ]]; then
                (cd "$dir" && run_privileged pip3 install . 2>&1 | tee -a "$ATDP_LOG_FILE" "$install_log")
            else
                (cd "$dir" && run_privileged python3 setup.py install 2>&1 | tee -a "$ATDP_LOG_FILE" "$install_log")
            fi
            ret="${PIPESTATUS[0]}"
            ;;
        nodejs)
            log_info "  → npm install -g"
            (cd "$dir" && run_privileged npm install -g . 2>&1 | tee -a "$ATDP_LOG_FILE" "$install_log")
            ret="${PIPESTATUS[0]}"
            ;;
        scons)
            log_info "  → scons install"
            (cd "$dir" && run_privileged scons install 2>&1 | tee -a "$ATDP_LOG_FILE" "$install_log")
            ret="${PIPESTATUS[0]}"
            ;;
        ninja)
            log_info "  → ninja install"
            (cd "$dir" && run_privileged ninja install 2>&1 | tee -a "$ATDP_LOG_FILE" "$install_log")
            ret="${PIPESTATUS[0]}"
            ;;
        *)
            # Autotools / make classique
            log_info "  → make install"
            (cd "$dir" && run_privileged make install 2>&1 | tee -a "$ATDP_LOG_FILE" "$install_log")
            ret="${PIPESTATUS[0]}"
            ;;
    esac

    # Capture la liste des fichiers installés (sert au rollback) AVANT de nettoyer le log temporaire
    ATDP_INSTALLED_FILES_LIST="$(_extract_installed_files_from_log "$install_log" | sort -u)"
    rm -f "$install_log"

    if [[ "$ret" -ne 0 ]]; then
        log_error "Installation échouée (code $ret)."
        return "$ret"
    fi

    log_ok "Installation terminée."
    if [[ -n "$ATDP_INSTALLED_FILES_LIST" ]]; then
        log_debug "Fichiers installés détectés : $(echo "$ATDP_INSTALLED_FILES_LIST" | wc -l)"
    fi
    return 0
}

# =============================================================================
# Phase 10 : Vérification finale
# =============================================================================
verify_installation() {
    local dir="$1"
    local software_name
    software_name="$(basename "$dir" | sed 's/[-_][0-9].*//')"
    log_step "PHASE 10 : Vérification finale"

    # Cherche le binaire principal dans le PATH
    local bin_found=""
    local candidate_bins=(
        "$software_name"
        "${software_name,,}"
        "$(echo "$software_name" | tr '[:upper:]' '[:lower:]')"
    )

    for b in "${candidate_bins[@]}"; do
        if command_exists "$b"; then
            bin_found="$b"
            break
        fi
    done

    if [[ -n "$bin_found" ]]; then
        log_ok "Binaire '$bin_found' trouvé dans le PATH."
        ATDP_INSTALLED_BINARIES+=("$bin_found")

        # Test --version
        local version_output
        version_output="$("$bin_found" --version 2>&1 | head -1)" || \
        version_output="$("$bin_found" -version 2>&1 | head -1)" || \
        version_output="(test --version non disponible)"
        log_info "Version : $version_output"
        export ATDP_INSTALLED_VERSION="$version_output"
    else
        log_warn "Binaire '$software_name' non trouvé dans le PATH."
        log_warn "L'installation a peut-être réussi dans un chemin non standard."

        # Cherche dans /usr/local/bin, /usr/bin, etc.
        local found_path
        found_path="$(find /usr/local/bin /usr/bin /opt /usr/local/sbin 2>/dev/null \
            -name "${software_name}*" -type f -executable 2>/dev/null | head -3)"
        if [[ -n "$found_path" ]]; then
            log_info "Fichiers trouvés :"
            echo "$found_path" | while IFS= read -r p; do log_info "  • $p"; done
        fi
    fi

    return 0
}
